import React from "react";
import { BrowserRouter as Router, Route } from "react-router-dom";
import "./icons.js";
import BancoDeDados from "./screens/BancoDeDados";
import Dashboard from "./screens/Dashboard";
import Login from "./screens/Login";
import Recomendacao1 from "./screens/Recomendacao1";
import Usuarios from "./screens/Usuarios";
import "./style.css";

function App() {
  return (
    <Router>
      <Route path="/" exact component={BancoDeDados} />
      <Route path="/BancoDeDados/" exact component={BancoDeDados} />
      <Route path="/Dashboard/" exact component={Dashboard} />
      <Route path="/Login/" exact component={Login} />
      <Route path="/Recomendacao1/" exact component={Recomendacao1} />
      <Route path="/Usuarios/" exact component={Usuarios} />
    </Router>
  );
}

export default App;
