import React, { Component } from "react";
import styled, { css } from "styled-components";
import CupertinoSearchBarWithCancelButton from "../components/CupertinoSearchBarWithCancelButton";
import EntypoIcon from "react-native-vector-icons/dist/Entypo";
import MaterialCheckboxWithLabel1 from "../components/MaterialCheckboxWithLabel1";
import MaterialCheckboxWithLabel2 from "../components/MaterialCheckboxWithLabel2";
import MaterialCommunityIconsIcon from "react-native-vector-icons/dist/MaterialCommunityIcons";
import MaterialIconsIcon from "react-native-vector-icons/dist/MaterialIcons";
import IoniconsIcon from "react-native-vector-icons/dist/Ionicons";
import FeatherIcon from "react-native-vector-icons/dist/Feather";

function Dashboard(props) {
  return (
    <Container>
      <Rect5Stack>
        <Rect5></Rect5>
        <ScrollArea>
          <Rect7>
            <CupertinoSearchBarWithCancelButtonRow>
              <CupertinoSearchBarWithCancelButton
                style={{
                  height: 44,
                  width: 331,
                  borderRadius: 7
                }}
              ></CupertinoSearchBarWithCancelButton>
              <Group59>
                <Rect18>
                  <Anos3Row>
                    <Anos3>Anos</Anos3>
                    <EntypoIcon
                      name="chevron-down"
                      style={{
                        color: "rgba(128,128,128,1)",
                        fontSize: 20,
                        height: 23,
                        width: 20,
                        marginLeft: 11
                      }}
                    ></EntypoIcon>
                  </Anos3Row>
                </Rect18>
              </Group59>
              <Rect8Column>
                <Rect8>
                  <Estados3Row>
                    <Estados3>Estados</Estados3>
                    <EntypoIcon
                      name="chevron-down"
                      style={{
                        color: "rgba(128,128,128,1)",
                        fontSize: 20,
                        height: 23,
                        width: 20,
                        marginLeft: 50
                      }}
                    ></EntypoIcon>
                  </Estados3Row>
                </Rect8>
                <Rect9>
                  <Municipios1Row>
                    <Municipios1>Municípios</Municipios1>
                    <EntypoIcon
                      name="chevron-down"
                      style={{
                        color: "rgba(128,128,128,1)",
                        fontSize: 20,
                        height: 23,
                        width: 20,
                        marginLeft: 26
                      }}
                    ></EntypoIcon>
                  </Municipios1Row>
                </Rect9>
              </Rect8Column>
              <MaterialCheckboxWithLabel1Stack>
                <MaterialCheckboxWithLabel1
                  style={{
                    height: 40,
                    width: 90,
                    position: "absolute",
                    left: 10,
                    top: 0
                  }}
                  label=" IMAGEM"
                ></MaterialCheckboxWithLabel1>
                <MaterialCheckboxWithLabel2
                  style={{
                    height: 40,
                    width: 90,
                    position: "absolute",
                    left: 0,
                    top: 32
                  }}
                  checkLabel="Pesquisas Foto"
                ></MaterialCheckboxWithLabel2>
              </MaterialCheckboxWithLabel1Stack>
              <Estados4Stack>
                <Estados4>Estados</Estados4>
                <Rect19>
                  <Pragas2Row>
                    <Pragas2>Pragas</Pragas2>
                    <EntypoIcon
                      name="chevron-down"
                      style={{
                        color: "rgba(128,128,128,1)",
                        fontSize: 20,
                        height: 23,
                        width: 20,
                        marginLeft: 62
                      }}
                    ></EntypoIcon>
                  </Pragas2Row>
                </Rect19>
              </Estados4Stack>
            </CupertinoSearchBarWithCancelButtonRow>
          </Rect7>
          <Group41StackStackStackStack>
            <Group41StackStackStack>
              <Group41StackStack>
                <Group41Stack>
                  <Group41>
                    <Rect6>
                      <MaterialCommunityIconsIcon
                        name="map-search"
                        style={{
                          color: "rgba(128,128,128,1)",
                          fontSize: 200,
                          height: 218,
                          width: 200,
                          marginTop: 116,
                          marginLeft: 100
                        }}
                      ></MaterialCommunityIconsIcon>
                    </Rect6>
                  </Group41>
                  <Group57>
                    <Rect15>
                      <Mes1Row>
                        <Mes1>Mês</Mes1>
                        <Group58>
                          <Rect16Stack>
                            <Rect16></Rect16>
                            <Anos2>Anos</Anos2>
                            <EntypoIcon
                              name="chevron-down"
                              style={{
                                top: 0,
                                left: 55,
                                position: "absolute",
                                color: "rgba(128,128,128,1)",
                                fontSize: 25
                              }}
                            ></EntypoIcon>
                          </Rect16Stack>
                        </Group58>
                      </Mes1Row>
                      <Rect17></Rect17>
                    </Rect15>
                  </Group57>
                </Group41Stack>
                <Group45>
                  <Rect10>
                    <Avaliacao1>Feedback de Recomendação</Avaliacao1>
                    <svg
                      viewBox="0 0 230 223.01"
                      style={{
                        width: 230,
                        height: 223,
                        marginTop: 16,
                        marginLeft: 34
                      }}
                    >
                      <ellipse
                        stroke="rgba(230, 230, 230,1)"
                        strokeWidth={0}
                        fill="rgba(230, 230, 230,1)"
                        cx={115}
                        cy={112}
                        rx={115}
                        ry={112}
                      ></ellipse>
                    </svg>
                    <Group46>
                      <Group47Row>
                        <Group47>
                          <Icon13Row>
                            <EntypoIcon
                              name="controller-stop"
                              style={{
                                color: "rgba(74,144,226,1)",
                                fontSize: 20
                              }}
                            ></EntypoIcon>
                            <Positivo1>Positivo</Positivo1>
                          </Icon13Row>
                        </Group47>
                        <Group48>
                          <Icon14Row>
                            <EntypoIcon
                              name="controller-stop"
                              style={{
                                color: "rgba(74,144,226,1)",
                                fontSize: 20
                              }}
                            ></EntypoIcon>
                            <Negativa1>Negativa</Negativa1>
                          </Icon14Row>
                        </Group48>
                      </Group47Row>
                      <Group49>
                        <Icon15Row>
                          <EntypoIcon
                            name="controller-stop"
                            style={{
                              color: "rgba(74,144,226,1)",
                              fontSize: 20
                            }}
                          ></EntypoIcon>
                          <Intermediaria1>Intermediária</Intermediaria1>
                        </Icon15Row>
                      </Group49>
                    </Group46>
                  </Rect10>
                </Group45>
              </Group41StackStack>
              <Group55>
                <Rect12>
                  <Anos1Row>
                    <Anos1>Anos</Anos1>
                    <Group56>
                      <Rect13Stack>
                        <Rect13></Rect13>
                        <EntypoIcon
                          name="chevron-down"
                          style={{
                            top: 0,
                            left: 34,
                            position: "absolute",
                            color: "rgba(128,128,128,1)",
                            fontSize: 25
                          }}
                        ></EntypoIcon>
                        <N20>Nº</N20>
                      </Rect13Stack>
                    </Group56>
                  </Anos1Row>
                  <Rect14></Rect14>
                </Rect12>
              </Group55>
            </Group41StackStackStack>
            <Group50>
              <Rect11>
                <Avaliacao2>Feedback De Classificação</Avaliacao2>
                <svg
                  viewBox="0 0 230 223.01"
                  style={{
                    width: 230,
                    height: 223,
                    marginTop: 18,
                    marginLeft: 33
                  }}
                >
                  <ellipse
                    stroke="rgba(230, 230, 230,1)"
                    strokeWidth={0}
                    fill="rgba(230, 230, 230,1)"
                    cx={115}
                    cy={112}
                    rx={115}
                    ry={112}
                  ></ellipse>
                </svg>
                <Group51>
                  <Group52Row>
                    <Group52>
                      <Icon16Row>
                        <EntypoIcon
                          name="controller-stop"
                          style={{
                            color: "rgba(74,144,226,1)",
                            fontSize: 20
                          }}
                        ></EntypoIcon>
                        <Positivo2>Positivo</Positivo2>
                      </Icon16Row>
                    </Group52>
                    <Group54>
                      <Icon18Row>
                        <EntypoIcon
                          name="controller-stop"
                          style={{
                            color: "rgba(74,144,226,1)",
                            fontSize: 20
                          }}
                        ></EntypoIcon>
                        <Negativa2>Negativa</Negativa2>
                      </Icon18Row>
                    </Group54>
                  </Group52Row>
                  <Group53>
                    <Icon17Row>
                      <EntypoIcon
                        name="controller-stop"
                        style={{
                          color: "rgba(74,144,226,1)",
                          fontSize: 20
                        }}
                      ></EntypoIcon>
                      <Intermediaria2>Intermediária</Intermediaria2>
                    </Icon17Row>
                  </Group53>
                </Group51>
              </Rect11>
            </Group50>
          </Group41StackStackStackStack>
        </ScrollArea>
        <Rect>
          <Rect2></Rect2>
          <Rect3></Rect3>
        </Rect>
        <Group>
          <ImageRow>
            <Image
              src={require("../assets/images/8c4f7617-8963-4c00-b5ae-44c1e2bfe4df_200x2001.png")}
            ></Image>
            <PragasTracker>Pragas Tracker</PragasTracker>
          </ImageRow>
        </Group>
        <Group40>
          <Group2>
            <Group39>
              <Icon4Row>
                <MaterialCommunityIconsIcon
                  name="view-dashboard-outline"
                  style={{
                    color: "rgba(0,0,0,0.7)",
                    fontSize: 25
                  }}
                ></MaterialCommunityIconsIcon>
                <Text>Dashboard</Text>
              </Icon4Row>
            </Group39>
          </Group2>
          <Group3>
            <Icon5Row>
              <EntypoIcon
                name="user"
                style={{
                  color: "rgba(0,0,0,0.7)",
                  fontSize: 25
                }}
              ></EntypoIcon>
              <Usuarios>Usuários</Usuarios>
            </Icon5Row>
          </Group3>
          <Group4>
            <Icon6Row>
              <MaterialCommunityIconsIcon
                name="file-document-box-multiple"
                style={{
                  color: "rgba(0,0,0,0.7)",
                  fontSize: 25
                }}
              ></MaterialCommunityIconsIcon>
              <Recomendacoes>Recomendações</Recomendacoes>
            </Icon6Row>
          </Group4>
          <Group5>
            <Icon8Row>
              <EntypoIcon
                name="database"
                style={{
                  color: "rgba(0,0,0,0.7)",
                  fontSize: 25
                }}
              ></EntypoIcon>
              <BancoDeDados>Banco de Dados</BancoDeDados>
            </Icon8Row>
          </Group5>
          <Group6>
            <Icon9Row>
              <MaterialIconsIcon
                name="class"
                style={{
                  color: "rgba(0,0,0,0.7)",
                  fontSize: 25
                }}
              ></MaterialIconsIcon>
              <Classificadores>Classificadores</Classificadores>
            </Icon9Row>
          </Group6>
          <Group7>
            <Icon7Row>
              <EntypoIcon
                name="image-inverted"
                style={{
                  color: "rgba(0,0,0,0.7)",
                  fontSize: 25
                }}
              ></EntypoIcon>
              <ImagensClassifica>Imagens Classificadas</ImagensClassifica>
            </Icon7Row>
          </Group7>
        </Group40>
        <Group33>
          <BemvindoAmaury>Bemvindo Amaury</BemvindoAmaury>
          <Group32>
            <Icon3Row>
              <IoniconsIcon
                name="ios-person-add"
                style={{
                  color: "rgba(0,0,0,0.7)",
                  fontSize: 25
                }}
              ></IoniconsIcon>
              <CadastrarAdmin>Cadastrar admin</CadastrarAdmin>
            </Icon3Row>
          </Group32>
          <Group31>
            <IconRow>
              <FeatherIcon
                name="settings"
                style={{
                  color: "rgba(0,0,0,0.7)",
                  fontSize: 25
                }}
              ></FeatherIcon>
              <Configuracoes>Configurações</Configuracoes>
            </IconRow>
          </Group31>
          <Group30>
            <Icon2Row>
              <FeatherIcon
                name="log-out"
                style={{
                  color: "rgba(0,0,0,0.7)",
                  fontSize: 25
                }}
              ></FeatherIcon>
              <Sair>Sair</Sair>
            </Icon2Row>
          </Group30>
        </Group33>
      </Rect5Stack>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  background-color: rgba(50,104,171,1);
  border-width: 0px;
  border-color: #000000;
  flex-direction: column;
  border-style: solid;
  height: 100vh;
  width: 100vw;
`;

const Rect5 = styled.div`
  top: 77px;
  left: 8px;
  width: 297px;
  height: 36px;
  position: absolute;
  background-color: rgba(185,235,197,1);
  border-radius: 17px;
`;

const ScrollArea = styled.div`
  overflow-y: scroll;
  top: 0px;
  left: 270px;
  width: 1040px;
  height: 700px;
  position: absolute;
  background-color: rgba(185,235,197,1);
  border-radius: 17px;
  flex-direction: column;
  display: flex;
  box-shadow: 3px 3px 50px  1px rgba(185,235,197,1) ;
`;

const Rect7 = styled.div`
  width: 1021px;
  height: 80px;
  background-color: rgba(243,241,241,1);
  border-radius: 17px;
  flex-direction: column;
  display: flex;
  margin-top: 8px;
  margin-left: 10px;
  flex: 0 0 auto;
  box-shadow: 3px 3px 50px  1px rgba(243,241,241,1) ;
`;

const Group59 = styled.div`
  width: 77px;
  height: 25px;
  flex-direction: column;
  display: flex;
  margin-left: 6px;
  margin-top: 9px;
`;

const Rect18 = styled.div`
  width: 77px;
  height: 25px;
  background-color: #E6E6E6;
  flex-direction: row;
  display: flex;
`;

const Anos3 = styled.span`
  font-family: Alegreya SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 16px;
`;

const Anos3Row = styled.div`
  height: 23px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: 4px;
  margin-left: 6px;
  margin-top: 1px;
`;

const Rect8 = styled.div`
  width: 137px;
  height: 25px;
  background-color: #E6E6E6;
  flex-direction: row;
  display: flex;
`;

const Estados3 = styled.span`
  font-family: Alegreya SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 16px;
`;

const Estados3Row = styled.div`
  height: 23px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: 3px;
  margin-left: 6px;
  margin-top: 1px;
`;

const Rect9 = styled.div`
  width: 137px;
  height: 24px;
  background-color: #E6E6E6;
  flex-direction: row;
  display: flex;
  margin-top: 6px;
`;

const Municipios1 = styled.span`
  font-family: Alegreya SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 16px;
  text-align: center;
`;

const Municipios1Row = styled.div`
  height: 23px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: 4px;
  margin-left: 6px;
  margin-top: 1px;
`;

const Rect8Column = styled.div`
  width: 137px;
  flex-direction: column;
  display: flex;
  margin-left: 14px;
  margin-top: 9px;
  margin-bottom: 8px;
`;

const MaterialCheckboxWithLabel1Stack = styled.div`
  width: 100px;
  height: 72px;
  margin-left: 15px;
  position: relative;
`;

const Estados4 = styled.span`
  font-family: Alegreya SC;
  top: 1px;
  left: 6px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 16px;
`;

const Rect19 = styled.div`
  top: 0px;
  left: 0px;
  width: 137px;
  height: 25px;
  position: absolute;
  background-color: #E6E6E6;
  flex-direction: row;
  display: flex;
`;

const Pragas2 = styled.span`
  font-family: Alegreya SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 16px;
`;

const Pragas2Row = styled.div`
  height: 24px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: 3px;
  margin-left: 2px;
  margin-top: 1px;
`;

const Estados4Stack = styled.div`
  width: 137px;
  height: 25px;
  margin-left: 50px;
  margin-top: 8px;
  position: relative;
`;

const CupertinoSearchBarWithCancelButtonRow = styled.div`
  height: 72px;
  flex-direction: row;
  display: flex;
  margin-top: 7px;
  margin-right: 154px;
`;

const Group41 = styled.div`
  top: 0px;
  left: 95px;
  width: 410px;
  height: 433px;
  position: absolute;
  flex-direction: column;
  display: flex;
`;

const Rect6 = styled.div`
  width: 410px;
  height: 433px;
  background-color: rgba(243,241,241,1);
  border-radius: 17px;
  flex-direction: column;
  display: flex;
  box-shadow: 3px 3px 50px  1px rgba(243,241,241,1) ;
`;

const Group57 = styled.div`
  top: 352px;
  left: 0px;
  width: 505px;
  height: 240px;
  position: absolute;
  flex-direction: column;
  display: flex;
`;

const Rect15 = styled.div`
  width: 505px;
  height: 240px;
  background-color: rgba(243,241,241,1);
  border-radius: 17px;
  flex-direction: column;
  display: flex;
  box-shadow: 3px 3px 50px  1px rgba(243,241,241,1) ;
`;

const Mes1 = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 700;
  color: #121212;
  font-size: 20px;
  text-align: center;
  text-decoration-line: underline;
`;

const Group58 = styled.div`
  width: 80px;
  height: 27px;
  flex-direction: column;
  display: flex;
  margin-left: 367px;
`;

const Rect16 = styled.div`
  top: 4px;
  left: 0px;
  width: 80px;
  height: 21px;
  position: absolute;
  background-color: #E6E6E6;
`;

const Anos2 = styled.span`
  font-family: Alegreya SC;
  top: 2px;
  left: 6px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 17px;
`;

const Rect16Stack = styled.div`
  width: 80px;
  height: 27px;
  position: relative;
`;

const Mes1Row = styled.div`
  height: 27px;
  flex-direction: row;
  display: flex;
  margin-top: 11px;
  margin-left: 11px;
  margin-right: 13px;
`;

const Rect17 = styled.div`
  width: 478px;
  height: 188px;
  background-color: #E6E6E6;
  margin-top: 5px;
  margin-left: 14px;
`;

const Group41Stack = styled.div`
  top: 0px;
  left: 211px;
  width: 505px;
  height: 592px;
  position: absolute;
`;

const Group45 = styled.div`
  top: 0px;
  left: 0px;
  width: 295px;
  height: 343px;
  position: absolute;
  flex-direction: column;
  display: flex;
`;

const Rect10 = styled.div`
  width: 295px;
  height: 343px;
  background-color: rgba(243,241,241,1);
  border-radius: 17px;
  flex-direction: column;
  display: flex;
  box-shadow: 3px 3px 50px  1px rgba(243,241,241,1) ;
`;

const Avaliacao1 = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 700;
  color: #121212;
  font-size: 20px;
  text-decoration-line: underline;
  margin-top: 10px;
  margin-left: 30px;
`;

const Group46 = styled.div`
  width: 243px;
  height: 50px;
  flex-direction: column;
  display: flex;
  margin-top: 11px;
  margin-left: 25px;
`;

const Group47 = styled.div`
  width: 76px;
  height: 22px;
  flex-direction: row;
  display: flex;
`;

const Positivo1 = styled.span`
  font-family: Alegreya SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  margin-left: 3px;
  margin-top: 2px;
`;

const Icon13Row = styled.div`
  height: 23px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: 1px;
`;

const Group48 = styled.div`
  width: 80px;
  height: 22px;
  flex-direction: row;
  display: flex;
  margin-left: 88px;
  margin-top: 1px;
`;

const Negativa1 = styled.span`
  font-family: Alegreya SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  margin-left: 3px;
`;

const Icon14Row = styled.div`
  height: 23px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: 1px;
`;

const Group47Row = styled.div`
  height: 23px;
  flex-direction: row;
  display: flex;
  margin-right: -1px;
`;

const Group49 = styled.div`
  width: 112px;
  height: 22px;
  flex-direction: row;
  display: flex;
  margin-top: 5px;
  margin-left: 61px;
`;

const Intermediaria1 = styled.span`
  font-family: Alegreya SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  margin-left: 2px;
  margin-top: 2px;
`;

const Icon15Row = styled.div`
  height: 23px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
`;

const Group41StackStack = styled.div`
  top: 0px;
  left: 305px;
  width: 716px;
  height: 592px;
  position: absolute;
`;

const Group55 = styled.div`
  top: 352px;
  left: 0px;
  width: 505px;
  height: 240px;
  position: absolute;
  flex-direction: column;
  display: flex;
`;

const Rect12 = styled.div`
  width: 505px;
  height: 240px;
  background-color: rgba(243,241,241,1);
  border-radius: 17px;
  flex-direction: column;
  display: flex;
  box-shadow: 3px 3px 50px  1px rgba(243,241,241,1) ;
`;

const Anos1 = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 700;
  color: #121212;
  font-size: 20px;
  text-align: center;
  text-decoration-line: underline;
  margin-top: 1px;
`;

const Group56 = styled.div`
  width: 60px;
  height: 27px;
  flex-direction: column;
  display: flex;
  margin-left: 375px;
`;

const Rect13 = styled.div`
  top: 4px;
  left: 0px;
  width: 60px;
  height: 21px;
  position: absolute;
  background-color: #E6E6E6;
`;

const N20 = styled.span`
  font-family: Alegreya SC;
  top: 2px;
  left: 6px;
  position: absolute;
  font-style: normal;
  font-weight: 700;
  color: #121212;
  font-size: 17px;
`;

const Rect13Stack = styled.div`
  width: 60px;
  height: 27px;
  position: relative;
`;

const Anos1Row = styled.div`
  height: 27px;
  flex-direction: row;
  display: flex;
  margin-top: 8px;
  margin-left: 13px;
  margin-right: 13px;
`;

const Rect14 = styled.div`
  width: 478px;
  height: 188px;
  background-color: #E6E6E6;
  margin-top: 7px;
  margin-left: 12px;
`;

const Group41StackStackStack = styled.div`
  top: 0px;
  left: 0px;
  width: 1021px;
  height: 592px;
  position: absolute;
`;

const Group50 = styled.div`
  top: 0px;
  left: 0px;
  width: 295px;
  height: 343px;
  position: absolute;
  flex-direction: column;
  display: flex;
`;

const Rect11 = styled.div`
  width: 295px;
  height: 343px;
  background-color: rgba(243,241,241,1);
  border-radius: 17px;
  flex-direction: column;
  display: flex;
  box-shadow: 3px 3px 50px  1px rgba(243,241,241,1) ;
`;

const Avaliacao2 = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 700;
  color: #121212;
  font-size: 20px;
  text-decoration-line: underline;
  margin-top: 10px;
  margin-left: 36px;
`;

const Group51 = styled.div`
  width: 243px;
  height: 50px;
  flex-direction: column;
  display: flex;
  margin-top: 10px;
  margin-left: 24px;
`;

const Group52 = styled.div`
  width: 76px;
  height: 22px;
  flex-direction: row;
  display: flex;
  margin-top: 1px;
`;

const Positivo2 = styled.span`
  font-family: Alegreya SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  margin-left: 3px;
  margin-top: 2px;
`;

const Icon16Row = styled.div`
  height: 23px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: 1px;
`;

const Group54 = styled.div`
  width: 80px;
  height: 22px;
  flex-direction: row;
  display: flex;
  margin-left: 88px;
`;

const Negativa2 = styled.span`
  font-family: Alegreya SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  margin-left: 3px;
  margin-top: 1px;
`;

const Icon18Row = styled.div`
  height: 23px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: 1px;
`;

const Group52Row = styled.div`
  height: 23px;
  flex-direction: row;
  display: flex;
  margin-right: -1px;
`;

const Group53 = styled.div`
  width: 112px;
  height: 22px;
  flex-direction: row;
  display: flex;
  margin-top: 5px;
  margin-left: 61px;
`;

const Intermediaria2 = styled.span`
  font-family: Alegreya SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  margin-left: 2px;
  margin-top: 2px;
`;

const Icon17Row = styled.div`
  height: 23px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
`;

const Group41StackStackStackStack = styled.div`
  width: 1021px;
  height: 592px;
  margin-top: 370px;
  margin-left: 10px;
  flex: 0 0 auto;
  position: relative;
  display: flex;
  flex-direction: column;
`;

const Rect = styled.div`
  left: 0px;
  width: 250px;
  height: 700px;
  position: absolute;
  background-color: rgba(230,230, 230,0.8);
  border-radius: 17px;
  flex-direction: column;
  opacity: 0.7;
  top: 0px;
  display: flex;
  box-shadow: 3px 3px 50px  1px rgba(185,235,197,1) ;
`;

const Rect2 = styled.div`
  flex: 0.67 1 0%;
  background-color: rgba(221, 221, 221,0);
  display: flex;
  flex-direction: column;
`;

const Rect3 = styled.div`
  flex: 0.32999999999999996 1 0%;
  background-color: rgba(246, 246, 246,1);
  margin: 5px;
  padding: 0px;
  border-width: -1px;
  border-color: #000000;
  border-radius: 17px;
  border-style: solid;
  display: flex;
  flex-direction: column;
`;

const Group = styled.div`
  top: 14px;
  left: 4px;
  width: 240px;
  height: 32px;
  position: absolute;
  overflow: visible;
  flex-direction: row;
  display: flex;
`;

const Image = styled.img`
  width: 100%;
  height: 41px;
  object-fit: contain;
`;

const PragasTracker = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 30px;
  margin-top: 2px;
`;

const ImageRow = styled.div`
  height: 41px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: 5px;
`;

const Group40 = styled.div`
  top: 81px;
  left: 20px;
  width: 222px;
  height: 263px;
  position: absolute;
  flex-direction: column;
  display: flex;
`;

const Group2 = styled.div`
  width: 133px;
  height: 27px;
  flex-direction: column;
  display: flex;
`;

const Group39 = styled.div`
  width: 136px;
  height: 27px;
  flex-direction: row;
  display: flex;
`;

const Text = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 700;
  color: #121212;
  font-size: 20px;
  margin-left: 13px;
  margin-top: 2px;
`;

const Icon4Row = styled.div`
  height: 27px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
`;

const Group3 = styled.div`
  width: 115px;
  height: 28px;
  flex-direction: row;
  display: flex;
  margin-top: 17px;
  margin-left: 1px;
`;

const Usuarios = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 20px;
  margin-left: 13px;
  margin-top: 4px;
`;

const Icon5Row = styled.div`
  height: 28px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: 1px;
`;

const Group4 = styled.div`
  width: 170px;
  height: 27px;
  flex-direction: row;
  display: flex;
  margin-top: 18px;
  margin-left: 2px;
`;

const Recomendacoes = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 20px;
  margin-left: 13px;
  margin-top: 1px;
`;

const Icon6Row = styled.div`
  height: 27px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: -1px;
`;

const Group5 = styled.div`
  width: 172px;
  height: 27px;
  flex-direction: row;
  display: flex;
  margin-top: 20px;
  margin-left: 1px;
`;

const BancoDeDados = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 20px;
  margin-left: 13px;
  margin-top: 2px;
`;

const Icon8Row = styled.div`
  height: 27px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: 1px;
`;

const Group6 = styled.div`
  width: 170px;
  height: 25px;
  flex-direction: row;
  display: flex;
  margin-top: 22px;
`;

const Classificadores = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 20px;
  margin-left: 13px;
  margin-top: 1px;
`;

const Icon9Row = styled.div`
  height: 25px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: 1px;
`;

const Group7 = styled.div`
  width: 221px;
  height: 27px;
  flex-direction: row;
  display: flex;
  margin-top: 25px;
  margin-left: 1px;
`;

const ImagensClassifica = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 20px;
  margin-left: 12px;
  margin-top: 1px;
`;

const Icon7Row = styled.div`
  height: 27px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
`;

const Group33 = styled.div`
  top: 496px;
  left: 31px;
  width: 193px;
  height: 158px;
  position: absolute;
  flex-direction: column;
  display: flex;
`;

const BemvindoAmaury = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 25px;
`;

const Group32 = styled.div`
  width: 175px;
  height: 27px;
  flex-direction: row;
  display: flex;
  margin-top: 17px;
  margin-left: 6px;
`;

const CadastrarAdmin = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 20px;
  margin-left: 12px;
  margin-top: 2px;
`;

const Icon3Row = styled.div`
  height: 27px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
`;

const Group31 = styled.div`
  width: 157px;
  height: 25px;
  flex-direction: row;
  display: flex;
  margin-top: 16px;
  margin-left: 6px;
`;

const Configuracoes = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 20px;
  margin-left: 7px;
  margin-top: 1px;
`;

const IconRow = styled.div`
  height: 25px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: 1px;
`;

const Group30 = styled.div`
  width: 63px;
  height: 25px;
  flex-direction: row;
  display: flex;
  margin-top: 18px;
  margin-left: 6px;
`;

const Sair = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 20px;
  margin-left: 4px;
  margin-top: 1px;
`;

const Icon2Row = styled.div`
  height: 25px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: -1px;
`;

const Rect5Stack = styled.div`
  width: 1310px;
  height: 700px;
  margin-top: 34px;
  margin-left: 30px;
  position: relative;
`;

export default Dashboard;
