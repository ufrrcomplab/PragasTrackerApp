import React, { Component } from "react";
import styled, { css } from "styled-components";
import EntypoIcon from "react-native-vector-icons/dist/Entypo";
import MaterialCommunityIconsIcon from "react-native-vector-icons/dist/MaterialCommunityIcons";
import MaterialIconsIcon from "react-native-vector-icons/dist/MaterialIcons";
import IoniconsIcon from "react-native-vector-icons/dist/Ionicons";
import FeatherIcon from "react-native-vector-icons/dist/Feather";

function Usuarios(props) {
  return (
    <Container>
      <Group67>
        <Group66>
          <Group65>
            <Group64>
              <Group34Stack>
                <Group34>
                  <Rect5StackStack>
                    <Rect5Stack>
                      <Rect5></Rect5>
                      <Rect4>
                        <Group63>
                          <Group54Row>
                            <Group54>
                              <Rect7>
                                <Text3Row>
                                  <Text3>Usuários</Text3>
                                  <Group53>
                                    <Filtro1Row>
                                      <Filtro1>Filtro :</Filtro1>
                                      <Group51>
                                        <Rect8Stack>
                                          <Rect8></Rect8>
                                          <Estados1>Estados</Estados1>
                                          <EntypoIcon
                                            name="chevron-down"
                                            style={{
                                              top: 1,
                                              left: 128,
                                              position: "absolute",
                                              color: "rgba(128,128,128,1)",
                                              fontSize: 25
                                            }}
                                          ></EntypoIcon>
                                        </Rect8Stack>
                                      </Group51>
                                    </Filtro1Row>
                                    <Group52>
                                      <Rect9Stack>
                                        <Rect9></Rect9>
                                        <Municipios1>Municípios</Municipios1>
                                        <EntypoIcon
                                          name="chevron-down"
                                          style={{
                                            top: 0,
                                            left: 127,
                                            position: "absolute",
                                            color: "rgba(128,128,128,1)",
                                            fontSize: 25
                                          }}
                                        ></EntypoIcon>
                                      </Rect9Stack>
                                    </Group52>
                                  </Group53>
                                </Text3Row>
                              </Rect7>
                            </Group54>
                            <Group58>
                              <Rect14>
                                <TotalRow>
                                  <Total>Total:</Total>
                                  <Rect25></Rect25>
                                </TotalRow>
                              </Rect14>
                            </Group58>
                          </Group54Row>
                          <Group57Row>
                            <Group57>
                              <Rect10>
                                <Listas2>Listas</Listas2>
                                <Group50>
                                  <Group39Row>
                                    <Group39>
                                      <N15>Nº</N15>
                                      <Rect15></Rect15>
                                    </Group39>
                                    <Group40>
                                      <Nomes>Nomes</Nomes>
                                      <Rect16></Rect16>
                                    </Group40>
                                    <Group41>
                                      <Cpf>CPF</Cpf>
                                      <Rect17></Rect17>
                                    </Group41>
                                    <Group42>
                                      <EMail>E-mail</EMail>
                                      <Rect18></Rect18>
                                    </Group42>
                                    <Group43>
                                      <Instituicao>Instituição</Instituicao>
                                      <Rect19></Rect19>
                                    </Group43>
                                    <Group44>
                                      <Perfil>Perfil</Perfil>
                                      <Rect20></Rect20>
                                    </Group44>
                                    <Group45>
                                      <NDeTel>Nº de Tel</NDeTel>
                                      <Rect21></Rect21>
                                    </Group45>
                                  </Group39Row>
                                </Group50>
                              </Rect10>
                            </Group57>
                            <Group62>
                              <Rect13>
                                <Group61>
                                  <Group60Row>
                                    <Group60>
                                      <Imagens3>Imagens</Imagens3>
                                      <Rect24></Rect24>
                                    </Group60>
                                    <Group47>
                                      <Atualizar>Atualizar</Atualizar>
                                      <Rect23></Rect23>
                                    </Group47>
                                    <Group59>
                                      <Deletar>Deletar</Deletar>
                                      <Rect22></Rect22>
                                    </Group59>
                                  </Group60Row>
                                </Group61>
                              </Rect13>
                            </Group62>
                          </Group57Row>
                        </Group63>
                      </Rect4>
                      <Group8>
                        <Group2>
                          <Icon4Row>
                            <MaterialCommunityIconsIcon
                              name="view-dashboard-outline"
                              style={{
                                color: "rgba(0,0,0,0.7)",
                                fontSize: 25
                              }}
                            ></MaterialCommunityIconsIcon>
                            <Text>Dashboard</Text>
                          </Icon4Row>
                        </Group2>
                        <Group3>
                          <Icon5Row>
                            <EntypoIcon
                              name="user"
                              style={{
                                color: "rgba(0,0,0,0.7)",
                                fontSize: 25
                              }}
                            ></EntypoIcon>
                            <Text2>Usuários</Text2>
                          </Icon5Row>
                        </Group3>
                        <Group4>
                          <Icon6Row>
                            <MaterialCommunityIconsIcon
                              name="file-document-box-multiple"
                              style={{
                                color: "rgba(0,0,0,0.7)",
                                fontSize: 25
                              }}
                            ></MaterialCommunityIconsIcon>
                            <Recomendacoes>Recomendações</Recomendacoes>
                          </Icon6Row>
                        </Group4>
                        <Group5>
                          <Icon8Row>
                            <EntypoIcon
                              name="database"
                              style={{
                                color: "rgba(0,0,0,0.7)",
                                fontSize: 25
                              }}
                            ></EntypoIcon>
                            <BancoDeDados>Banco de Dados</BancoDeDados>
                          </Icon8Row>
                        </Group5>
                        <Group6>
                          <Icon9Row>
                            <MaterialIconsIcon
                              name="class"
                              style={{
                                color: "rgba(0,0,0,0.7)",
                                fontSize: 25
                              }}
                            ></MaterialIconsIcon>
                            <Classificadores>Classificadores</Classificadores>
                          </Icon9Row>
                        </Group6>
                        <Group7>
                          <Icon7Row>
                            <EntypoIcon
                              name="image-inverted"
                              style={{
                                color: "rgba(0,0,0,0.7)",
                                fontSize: 25
                              }}
                            ></EntypoIcon>
                            <ImagensClassifica>
                              Imagens Classificadas
                            </ImagensClassifica>
                          </Icon7Row>
                        </Group7>
                      </Group8>
                    </Rect5Stack>
                    <Group33>
                      <BemvindoAmaury>Bemvindo Amaury</BemvindoAmaury>
                      <Group32>
                        <Icon3Row>
                          <IoniconsIcon
                            name="ios-person-add"
                            style={{
                              color: "rgba(0,0,0,0.7)",
                              fontSize: 25
                            }}
                          ></IoniconsIcon>
                          <CadastrarAdmin>Cadastrar admin</CadastrarAdmin>
                        </Icon3Row>
                      </Group32>
                      <Group31>
                        <IconRow>
                          <FeatherIcon
                            name="settings"
                            style={{
                              color: "rgba(0,0,0,0.7)",
                              fontSize: 25
                            }}
                          ></FeatherIcon>
                          <Configuracoes>Configurações</Configuracoes>
                        </IconRow>
                      </Group31>
                      <Group30>
                        <Icon2Row>
                          <FeatherIcon
                            name="log-out"
                            style={{
                              color: "rgba(0,0,0,0.7)",
                              fontSize: 25
                            }}
                          ></FeatherIcon>
                          <Sair>Sair</Sair>
                        </Icon2Row>
                      </Group30>
                    </Group33>
                  </Rect5StackStack>
                </Group34>
                <Rect>
                  <Rect2></Rect2>
                  <Rect3></Rect3>
                </Rect>
                <Group>
                  <ImageRow>
                    <Image
                      src={require("../assets/images/8c4f7617-8963-4c00-b5ae-44c1e2bfe4df_200x2001.png")}
                    ></Image>
                    <PragasTracker>Pragas Tracker</PragasTracker>
                  </ImageRow>
                </Group>
              </Group34Stack>
            </Group64>
          </Group65>
        </Group66>
      </Group67>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  background-color: rgba(50,104,171,1);
  border-width: 0px;
  border-color: #000000;
  flex-direction: column;
  border-style: solid;
  height: 100vh;
  width: 100vw;
`;

const Group67 = styled.div`
  width: 1310px;
  height: 700px;
  flex-direction: column;
  display: flex;
  margin-top: 34px;
  margin-left: 30px;
`;

const Group66 = styled.div`
  width: 1310px;
  height: 700px;
  flex-direction: column;
  display: flex;
`;

const Group65 = styled.div`
  width: 1310px;
  height: 700px;
  flex-direction: column;
  display: flex;
`;

const Group64 = styled.div`
  width: 1310px;
  height: 700px;
  flex-direction: column;
  display: flex;
`;

const Group34 = styled.div`
  top: 0px;
  left: 8px;
  width: 1302px;
  height: 700px;
  position: absolute;
  flex-direction: column;
  display: flex;
`;

const Rect5 = styled.div`
  top: 121px;
  left: 0px;
  width: 297px;
  height: 36px;
  position: absolute;
  background-color: rgba(185,235,197,1);
  border-radius: 17px;
`;

const Rect4 = styled.div`
  top: 0px;
  left: 262px;
  width: 1040px;
  height: 700px;
  position: absolute;
  background-color: rgba(185,235,197,1);
  border-radius: 17px;
  flex-direction: column;
  display: flex;
  box-shadow: 3px 3px 50px  1px rgba(185,235,197,1) ;
`;

const Group63 = styled.div`
  width: 1018px;
  height: 682px;
  flex-direction: column;
  display: flex;
  margin-top: 10px;
  margin-left: 11px;
`;

const Group54 = styled.div`
  width: 730px;
  height: 80px;
  flex-direction: column;
  display: flex;
`;

const Rect7 = styled.div`
  width: 730px;
  height: 80px;
  background-color: rgba(243,241,241,1);
  border-radius: 17px;
  flex-direction: row;
  display: flex;
  box-shadow: 3px 3px 50px  1px rgba(243,241,241,1) ;
`;

const Text3 = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 700;
  color: #121212;
  font-size: 30px;
  margin-top: 8px;
`;

const Group53 = styled.div`
  width: 223px;
  height: 56px;
  flex-direction: column;
  display: flex;
  margin-left: 366px;
`;

const Filtro1 = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 20px;
  margin-top: 3px;
`;

const Group51 = styled.div`
  width: 154px;
  height: 28px;
  flex-direction: column;
  display: flex;
  margin-left: 11px;
`;

const Rect8 = styled.div`
  top: 5px;
  left: 0px;
  width: 153px;
  height: 20px;
  position: absolute;
  background-color: #E6E6E6;
`;

const Estados1 = styled.span`
  font-family: Alegreya SC;
  top: 0px;
  left: 6px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 16px;
`;

const Rect8Stack = styled.div`
  width: 153px;
  height: 28px;
  position: relative;
`;

const Filtro1Row = styled.div`
  height: 28px;
  flex-direction: row;
  display: flex;
`;

const Group52 = styled.div`
  width: 153px;
  height: 27px;
  flex-direction: column;
  display: flex;
  margin-top: 1px;
  margin-left: 69px;
`;

const Rect9 = styled.div`
  top: 5px;
  left: 0px;
  width: 153px;
  height: 20px;
  position: absolute;
  background-color: #E6E6E6;
`;

const Municipios1 = styled.span`
  font-family: Alegreya SC;
  top: 0px;
  left: 6px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 16px;
  text-align: center;
`;

const Rect9Stack = styled.div`
  width: 153px;
  height: 27px;
  position: relative;
`;

const Text3Row = styled.div`
  height: 56px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: 10px;
  margin-left: 12px;
  margin-top: 12px;
`;

const Group58 = styled.div`
  width: 280px;
  height: 80px;
  flex-direction: column;
  display: flex;
  margin-left: 8px;
`;

const Rect14 = styled.div`
  width: 280px;
  height: 80px;
  background-color: rgba(243,241,241,1);
  border-radius: 17px;
  flex-direction: row;
  display: flex;
  box-shadow: 3px 3px 50px  1px rgba(243,241,241,1) ;
`;

const Total = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 700;
  color: #121212;
  font-size: 30px;
  margin-top: 9px;
`;

const Rect25 = styled.div`
  width: 131px;
  height: 56px;
  background-color: #E6E6E6;
  margin-left: 34px;
`;

const TotalRow = styled.div`
  height: 56px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: 13px;
  margin-left: 26px;
  margin-top: 11px;
`;

const Group54Row = styled.div`
  height: 80px;
  flex-direction: row;
  display: flex;
`;

const Group57 = styled.div`
  width: 730px;
  height: 586px;
  flex-direction: column;
  display: flex;
`;

const Rect10 = styled.div`
  width: 730px;
  height: 586px;
  background-color: rgba(243,241,241,1);
  border-radius: 17px;
  flex-direction: column;
  display: flex;
  box-shadow: 3px 3px 50px  1px rgba(243,241,241,1) ;
`;

const Listas2 = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 700;
  color: #121212;
  font-size: 20px;
  text-align: center;
  text-decoration-line: underline;
  margin-top: 14px;
  margin-left: 12px;
`;

const Group50 = styled.div`
  width: 711px;
  height: 518px;
  flex-direction: row;
  display: flex;
  margin-top: 20px;
  margin-left: 9px;
`;

const Group39 = styled.div`
  width: 21px;
  height: 515px;
  flex-direction: column;
  display: flex;
  margin-top: 2px;
`;

const N15 = styled.span`
  font-family: Alegreya SC;
  font-style: normal;
  font-weight: 700;
  color: #121212;
  font-size: 16px;
  margin-left: 4px;
`;

const Rect15 = styled.div`
  width: 20px;
  height: 489px;
  background-color: #E6E6E6;
  margin-top: 4px;
`;

const Group40 = styled.div`
  width: 104px;
  height: 515px;
  flex-direction: column;
  display: flex;
  margin-left: 7px;
  margin-top: 2px;
`;

const Nomes = styled.span`
  font-family: Alegreya SC;
  font-style: normal;
  font-weight: 700;
  color: #121212;
  font-size: 16px;
  margin-left: 30px;
`;

const Rect16 = styled.div`
  width: 104px;
  height: 489px;
  background-color: #E6E6E6;
  margin-top: 4px;
`;

const Group41 = styled.div`
  width: 104px;
  height: 515px;
  flex-direction: column;
  display: flex;
  margin-left: 8px;
  margin-top: 2px;
`;

const Cpf = styled.span`
  font-family: Alegreya SC;
  font-style: normal;
  font-weight: 700;
  color: #121212;
  font-size: 16px;
  margin-left: 41px;
`;

const Rect17 = styled.div`
  width: 104px;
  height: 489px;
  background-color: #E6E6E6;
  margin-top: 4px;
`;

const Group42 = styled.div`
  width: 126px;
  height: 515px;
  flex-direction: column;
  display: flex;
  margin-left: 8px;
  margin-top: 4px;
`;

const EMail = styled.span`
  font-family: Alegreya SC;
  font-style: normal;
  font-weight: 700;
  color: #121212;
  font-size: 16px;
  margin-left: 43px;
`;

const Rect18 = styled.div`
  width: 126px;
  height: 489px;
  background-color: #E6E6E6;
  margin-top: 4px;
`;

const Group43 = styled.div`
  width: 126px;
  height: 518px;
  flex-direction: column;
  display: flex;
  margin-left: 7px;
`;

const Instituicao = styled.span`
  font-family: Alegreya SC;
  font-style: normal;
  font-weight: 700;
  color: #121212;
  font-size: 16px;
  margin-left: 24px;
`;

const Rect19 = styled.div`
  width: 126px;
  height: 489px;
  background-color: #E6E6E6;
  margin-top: 7px;
`;

const Group44 = styled.div`
  width: 90px;
  height: 515px;
  flex-direction: column;
  display: flex;
  margin-left: 5px;
  margin-top: 2px;
`;

const Perfil = styled.span`
  font-family: Alegreya SC;
  font-style: normal;
  font-weight: 700;
  color: #121212;
  font-size: 16px;
  margin-left: 23px;
`;

const Rect20 = styled.div`
  width: 90px;
  height: 489px;
  background-color: #E6E6E6;
  margin-top: 4px;
`;

const Group45 = styled.div`
  width: 95px;
  height: 515px;
  flex-direction: column;
  display: flex;
  margin-left: 10px;
  margin-top: 2px;
`;

const NDeTel = styled.span`
  font-family: Alegreya SC;
  font-style: normal;
  font-weight: 700;
  color: #121212;
  font-size: 16px;
  margin-left: 15px;
`;

const Rect21 = styled.div`
  width: 95px;
  height: 489px;
  background-color: #E6E6E6;
  margin-top: 4px;
`;

const Group39Row = styled.div`
  height: 519px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
`;

const Group62 = styled.div`
  width: 280px;
  height: 586px;
  flex-direction: column;
  display: flex;
  margin-left: 8px;
`;

const Rect13 = styled.div`
  width: 280px;
  height: 586px;
  background-color: rgba(243,241,241,1);
  border-radius: 17px;
  flex-direction: column;
  display: flex;
  box-shadow: 3px 3px 50px  1px rgba(243,241,241,1) ;
`;

const Group61 = styled.div`
  width: 259px;
  height: 519px;
  flex-direction: row;
  display: flex;
  margin-top: 58px;
  margin-left: 10px;
`;

const Group60 = styled.div`
  width: 83px;
  height: 517px;
  flex-direction: column;
  display: flex;
  margin-top: 2px;
`;

const Imagens3 = styled.span`
  font-family: Alegreya SC;
  font-style: normal;
  font-weight: 700;
  color: #121212;
  font-size: 16px;
  margin-left: 13px;
`;

const Rect24 = styled.div`
  width: 83px;
  height: 489px;
  background-color: #E6E6E6;
  margin-top: 6px;
`;

const Group47 = styled.div`
  width: 80px;
  height: 515px;
  flex-direction: column;
  display: flex;
  margin-left: 8px;
  margin-top: 3px;
`;

const Atualizar = styled.span`
  font-family: Alegreya SC;
  font-style: normal;
  font-weight: 700;
  color: #121212;
  font-size: 16px;
  margin-left: 6px;
`;

const Rect23 = styled.div`
  width: 80px;
  height: 489px;
  background-color: #E6E6E6;
  margin-top: 4px;
`;

const Group59 = styled.div`
  width: 80px;
  height: 519px;
  flex-direction: column;
  display: flex;
  margin-left: 8px;
`;

const Deletar = styled.span`
  font-family: Alegreya SC;
  font-style: normal;
  font-weight: 700;
  color: #121212;
  font-size: 16px;
  margin-left: 10px;
`;

const Rect22 = styled.div`
  width: 80px;
  height: 490px;
  background-color: #E6E6E6;
  margin-top: 7px;
`;

const Group60Row = styled.div`
  height: 519px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
`;

const Group57Row = styled.div`
  height: 586px;
  flex-direction: row;
  display: flex;
  margin-top: 16px;
`;

const Group8 = styled.div`
  top: 81px;
  left: 12px;
  width: 222px;
  height: 263px;
  position: absolute;
  flex-direction: column;
  display: flex;
`;

const Group2 = styled.div`
  width: 133px;
  height: 27px;
  flex-direction: row;
  display: flex;
`;

const Text = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 20px;
  margin-left: 13px;
  margin-top: 2px;
`;

const Icon4Row = styled.div`
  height: 27px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
`;

const Group3 = styled.div`
  width: 115px;
  height: 28px;
  flex-direction: row;
  display: flex;
  margin-top: 17px;
  margin-left: 1px;
`;

const Text2 = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 20px;
  margin-left: 13px;
  margin-top: 4px;
`;

const Icon5Row = styled.div`
  height: 28px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: 1px;
`;

const Group4 = styled.div`
  width: 170px;
  height: 27px;
  flex-direction: row;
  display: flex;
  margin-top: 18px;
  margin-left: 2px;
`;

const Recomendacoes = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 20px;
  margin-left: 13px;
  margin-top: 1px;
`;

const Icon6Row = styled.div`
  height: 27px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: -1px;
`;

const Group5 = styled.div`
  width: 172px;
  height: 27px;
  flex-direction: row;
  display: flex;
  margin-top: 20px;
  margin-left: 1px;
`;

const BancoDeDados = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 20px;
  margin-left: 13px;
  margin-top: 2px;
`;

const Icon8Row = styled.div`
  height: 27px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: 1px;
`;

const Group6 = styled.div`
  width: 170px;
  height: 25px;
  flex-direction: row;
  display: flex;
  margin-top: 22px;
`;

const Classificadores = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 20px;
  margin-left: 13px;
  margin-top: 1px;
`;

const Icon9Row = styled.div`
  height: 25px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: 1px;
`;

const Group7 = styled.div`
  width: 221px;
  height: 27px;
  flex-direction: row;
  display: flex;
  margin-top: 25px;
  margin-left: 1px;
`;

const ImagensClassifica = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 20px;
  margin-left: 12px;
  margin-top: 1px;
`;

const Icon7Row = styled.div`
  height: 27px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
`;

const Rect5Stack = styled.div`
  top: 0px;
  left: 0px;
  width: 1302px;
  height: 700px;
  position: absolute;
`;

const Group33 = styled.div`
  top: 496px;
  left: 23px;
  width: 193px;
  height: 158px;
  position: absolute;
  flex-direction: column;
  display: flex;
`;

const BemvindoAmaury = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 25px;
`;

const Group32 = styled.div`
  width: 175px;
  height: 27px;
  flex-direction: row;
  display: flex;
  margin-top: 17px;
  margin-left: 6px;
`;

const CadastrarAdmin = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 20px;
  margin-left: 12px;
  margin-top: 2px;
`;

const Icon3Row = styled.div`
  height: 27px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
`;

const Group31 = styled.div`
  width: 157px;
  height: 25px;
  flex-direction: row;
  display: flex;
  margin-top: 16px;
  margin-left: 6px;
`;

const Configuracoes = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 20px;
  margin-left: 7px;
  margin-top: 1px;
`;

const IconRow = styled.div`
  height: 25px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: 1px;
`;

const Group30 = styled.div`
  width: 63px;
  height: 25px;
  flex-direction: row;
  display: flex;
  margin-top: 18px;
  margin-left: 6px;
`;

const Sair = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 20px;
  margin-left: 4px;
  margin-top: 1px;
`;

const Icon2Row = styled.div`
  height: 25px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: -1px;
`;

const Rect5StackStack = styled.div`
  width: 1302px;
  height: 700px;
  position: relative;
`;

const Rect = styled.div`
  left: 0px;
  width: 250px;
  height: 700px;
  position: absolute;
  background-color: rgba(230,230, 230,0.8);
  border-radius: 17px;
  flex-direction: column;
  opacity: 0.7;
  top: 0px;
  display: flex;
  box-shadow: 3px 3px 50px  1px rgba(185,235,197,1) ;
`;

const Rect2 = styled.div`
  flex: 0.67 1 0%;
  background-color: rgba(221, 221, 221,0);
  display: flex;
  flex-direction: column;
`;

const Rect3 = styled.div`
  flex: 0.32999999999999996 1 0%;
  background-color: rgba(246, 246, 246,1);
  margin: 5px;
  padding: 0px;
  border-width: -1px;
  border-color: #000000;
  border-radius: 17px;
  border-style: solid;
  display: flex;
  flex-direction: column;
`;

const Group = styled.div`
  top: 14px;
  left: 4px;
  width: 240px;
  height: 32px;
  position: absolute;
  overflow: visible;
  flex-direction: row;
  display: flex;
`;

const Image = styled.img`
  width: 100%;
  height: 41px;
  object-fit: contain;
`;

const PragasTracker = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 30px;
  margin-top: 2px;
`;

const ImageRow = styled.div`
  height: 41px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: 5px;
`;

const Group34Stack = styled.div`
  width: 1310px;
  height: 700px;
  position: relative;
`;

export default Usuarios;
