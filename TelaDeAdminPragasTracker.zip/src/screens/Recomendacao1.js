import React, { Component } from "react";
import styled, { css } from "styled-components";
import OcticonsIcon from "react-native-vector-icons/dist/Octicons";
import FeatherIcon from "react-native-vector-icons/dist/Feather";
import FontAwesomeIcon from "react-native-vector-icons/dist/FontAwesome";
import EntypoIcon from "react-native-vector-icons/dist/Entypo";
import MaterialButtonPink from "../components/MaterialButtonPink";
import MaterialButtonPrimary2 from "../components/MaterialButtonPrimary2";
import MaterialCommunityIconsIcon from "react-native-vector-icons/dist/MaterialCommunityIcons";
import MaterialIconsIcon from "react-native-vector-icons/dist/MaterialIcons";
import IoniconsIcon from "react-native-vector-icons/dist/Ionicons";

function Recomendacao1(props) {
  return (
    <Container>
      <Group34Stack>
        <Group34>
          <Rect5StackStack>
            <Rect5Stack>
              <Rect5></Rect5>
              <Rect4>
                <Rect6Row>
                  <Rect6>
                    <Group55>
                      <BancoDeDados2>Banco de Dados</BancoDeDados2>
                      <Group54>
                        <Rect30>
                          <PastasDeDataset>Pastas de Dataset</PastasDeDataset>
                          <Group48>
                            <Group46Row>
                              <Group46>
                                <Icon15Stack>
                                  <OcticonsIcon
                                    name="file-directory"
                                    style={{
                                      top: 0,
                                      left: 0,
                                      position: "absolute",
                                      color: "rgba(128,128,128,1)",
                                      fontSize: 110
                                    }}
                                  ></OcticonsIcon>
                                  <Blissus>Blissus</Blissus>
                                </Icon15Stack>
                              </Group46>
                              <Group47>
                                <Icon17Stack>
                                  <OcticonsIcon
                                    name="file-directory"
                                    style={{
                                      top: 0,
                                      left: 0,
                                      position: "absolute",
                                      color: "rgba(128,128,128,1)",
                                      fontSize: 110
                                    }}
                                  ></OcticonsIcon>
                                  <Cigarrinha>Cigarrinha</Cigarrinha>
                                </Icon17Stack>
                              </Group47>
                              <FeatherIcon
                                name="folder-plus"
                                style={{
                                  color: "rgba(128,128,128,1)",
                                  fontSize: 40,
                                  marginLeft: 39,
                                  marginTop: 39
                                }}
                              ></FeatherIcon>
                            </Group46Row>
                          </Group48>
                        </Rect30>
                      </Group54>
                      <Group53>
                        <Rect31>
                          <PastasDeValidacao>
                            Pastas de Validação
                          </PastasDeValidacao>
                          <Group49Stack>
                            <Group49>
                              <Icon19Row>
                                <OcticonsIcon
                                  name="file-directory"
                                  style={{
                                    color: "rgba(128,128,128,1)",
                                    fontSize: 110
                                  }}
                                ></OcticonsIcon>
                                <FeatherIcon
                                  name="folder-plus"
                                  style={{
                                    color: "rgba(128,128,128,1)",
                                    fontSize: 40,
                                    marginLeft: 29,
                                    marginTop: 40
                                  }}
                                ></FeatherIcon>
                              </Icon19Row>
                            </Group49>
                            <Group45>
                              <Validation>Validation</Validation>
                            </Group45>
                          </Group49Stack>
                        </Rect31>
                      </Group53>
                    </Group55>
                  </Rect6>
                  <Group52>
                    <Rect21>
                      <Group50>
                        <Rect29>
                          <ImagensDaPasta>Imagens da pasta</ImagensDaPasta>
                          <Group43>
                            <Group40>
                              <Icon10Row>
                                <FontAwesomeIcon
                                  name="image"
                                  style={{
                                    color: "rgba(128,128,128,1)",
                                    fontSize: 100
                                  }}
                                ></FontAwesomeIcon>
                                <FontAwesomeIcon
                                  name="image"
                                  style={{
                                    color: "rgba(128,128,128,1)",
                                    fontSize: 100,
                                    marginLeft: 37
                                  }}
                                ></FontAwesomeIcon>
                                <FontAwesomeIcon
                                  name="image"
                                  style={{
                                    color: "rgba(128,128,128,1)",
                                    fontSize: 100,
                                    marginLeft: 35
                                  }}
                                ></FontAwesomeIcon>
                                <FontAwesomeIcon
                                  name="image"
                                  style={{
                                    color: "rgba(128,128,128,1)",
                                    fontSize: 100,
                                    marginLeft: 32
                                  }}
                                ></FontAwesomeIcon>
                              </Icon10Row>
                            </Group40>
                            <Group41>
                              <Icon26Row>
                                <FontAwesomeIcon
                                  name="image"
                                  style={{
                                    color: "rgba(128,128,128,1)",
                                    fontSize: 100
                                  }}
                                ></FontAwesomeIcon>
                                <FontAwesomeIcon
                                  name="image"
                                  style={{
                                    color: "rgba(128,128,128,1)",
                                    fontSize: 100,
                                    marginLeft: 37
                                  }}
                                ></FontAwesomeIcon>
                                <FontAwesomeIcon
                                  name="image"
                                  style={{
                                    color: "rgba(128,128,128,1)",
                                    fontSize: 100,
                                    marginLeft: 35
                                  }}
                                ></FontAwesomeIcon>
                                <FontAwesomeIcon
                                  name="image"
                                  style={{
                                    color: "rgba(128,128,128,1)",
                                    fontSize: 100,
                                    marginLeft: 32
                                  }}
                                ></FontAwesomeIcon>
                              </Icon26Row>
                            </Group41>
                            <Group42>
                              <Icon30Row>
                                <FontAwesomeIcon
                                  name="image"
                                  style={{
                                    color: "rgba(128,128,128,1)",
                                    fontSize: 100
                                  }}
                                ></FontAwesomeIcon>
                                <FontAwesomeIcon
                                  name="image"
                                  style={{
                                    color: "rgba(128,128,128,1)",
                                    fontSize: 100,
                                    marginLeft: 37
                                  }}
                                ></FontAwesomeIcon>
                                <FontAwesomeIcon
                                  name="image"
                                  style={{
                                    color: "rgba(128,128,128,1)",
                                    fontSize: 100,
                                    marginLeft: 35
                                  }}
                                ></FontAwesomeIcon>
                                <FontAwesomeIcon
                                  name="image"
                                  style={{
                                    color: "rgba(128,128,128,1)",
                                    fontSize: 100,
                                    marginLeft: 32
                                  }}
                                ></FontAwesomeIcon>
                              </Icon30Row>
                            </Group42>
                          </Group43>
                        </Rect29>
                      </Group50>
                      <Group51>
                        <Rect32>
                          <AdicionarImagens>Adicionar imagens</AdicionarImagens>
                          <Group44>
                            <Icon21Row>
                              <FontAwesomeIcon
                                name="image"
                                style={{
                                  color: "rgba(128,128,128,1)",
                                  fontSize: 100
                                }}
                              ></FontAwesomeIcon>
                              <FontAwesomeIcon
                                name="image"
                                style={{
                                  color: "rgba(128,128,128,1)",
                                  fontSize: 100,
                                  marginLeft: 13
                                }}
                              ></FontAwesomeIcon>
                              <FontAwesomeIcon
                                name="image"
                                style={{
                                  color: "rgba(128,128,128,1)",
                                  fontSize: 100,
                                  marginLeft: 13
                                }}
                              ></FontAwesomeIcon>
                              <FontAwesomeIcon
                                name="image"
                                style={{
                                  color: "rgba(128,128,128,1)",
                                  fontSize: 100,
                                  marginLeft: 13
                                }}
                              ></FontAwesomeIcon>
                              <EntypoIcon
                                name="squared-plus"
                                style={{
                                  color: "rgba(128,128,128,1)",
                                  fontSize: 40,
                                  marginLeft: 27,
                                  marginTop: 28
                                }}
                              ></EntypoIcon>
                            </Icon21Row>
                          </Group44>
                        </Rect32>
                      </Group51>
                      <Group39>
                        <MaterialButtonPinkRow>
                          <MaterialButtonPink
                            style={{
                              height: 36,
                              width: 100
                            }}
                            button="Cancelar"
                          ></MaterialButtonPink>
                          <MaterialButtonPrimary2
                            caption="BUTTON"
                            style={{
                              height: 36,
                              width: 140,
                              marginLeft: 25
                            }}
                            button="Salvar"
                          ></MaterialButtonPrimary2>
                        </MaterialButtonPinkRow>
                      </Group39>
                    </Rect21>
                  </Group52>
                </Rect6Row>
              </Rect4>
              <Group8>
                <Group2>
                  <Icon4Row>
                    <MaterialCommunityIconsIcon
                      name="view-dashboard-outline"
                      style={{
                        color: "rgba(0,0,0,0.7)",
                        fontSize: 25
                      }}
                    ></MaterialCommunityIconsIcon>
                    <Text>Dashboard</Text>
                  </Icon4Row>
                </Group2>
                <Group3>
                  <Icon5Row>
                    <EntypoIcon
                      name="user"
                      style={{
                        color: "rgba(0,0,0,0.7)",
                        fontSize: 25
                      }}
                    ></EntypoIcon>
                    <Text2>Usuários</Text2>
                  </Icon5Row>
                </Group3>
                <Group4>
                  <Icon6Row>
                    <MaterialCommunityIconsIcon
                      name="file-document-box-multiple"
                      style={{
                        color: "rgba(0,0,0,0.7)",
                        fontSize: 25
                      }}
                    ></MaterialCommunityIconsIcon>
                    <Recomendacoes>Recomendações</Recomendacoes>
                  </Icon6Row>
                </Group4>
                <Group5>
                  <Icon8Row>
                    <EntypoIcon
                      name="database"
                      style={{
                        color: "rgba(0,0,0,0.7)",
                        fontSize: 25
                      }}
                    ></EntypoIcon>
                    <BancoDeDados>Banco de Dados</BancoDeDados>
                  </Icon8Row>
                </Group5>
                <Group6>
                  <Icon9Row>
                    <MaterialIconsIcon
                      name="class"
                      style={{
                        color: "rgba(0,0,0,0.7)",
                        fontSize: 25
                      }}
                    ></MaterialIconsIcon>
                    <Classificadores>Classificadores</Classificadores>
                  </Icon9Row>
                </Group6>
                <Group7>
                  <Icon7Row>
                    <EntypoIcon
                      name="image-inverted"
                      style={{
                        color: "rgba(0,0,0,0.7)",
                        fontSize: 25
                      }}
                    ></EntypoIcon>
                    <ImagensClassifica>Imagens Classificadas</ImagensClassifica>
                  </Icon7Row>
                </Group7>
              </Group8>
            </Rect5Stack>
            <Group33>
              <BemvindoAmaury>Bemvindo Amaury</BemvindoAmaury>
              <Group32>
                <Icon3Row>
                  <IoniconsIcon
                    name="ios-person-add"
                    style={{
                      color: "rgba(0,0,0,0.7)",
                      fontSize: 25
                    }}
                  ></IoniconsIcon>
                  <CadastrarAdmin>Cadastrar admin</CadastrarAdmin>
                </Icon3Row>
              </Group32>
              <Group31>
                <IconRow>
                  <FeatherIcon
                    name="settings"
                    style={{
                      color: "rgba(0,0,0,0.7)",
                      fontSize: 25
                    }}
                  ></FeatherIcon>
                  <Configuracoes>Configurações</Configuracoes>
                </IconRow>
              </Group31>
              <Group30>
                <Icon2Row>
                  <FeatherIcon
                    name="log-out"
                    style={{
                      color: "rgba(0,0,0,0.7)",
                      fontSize: 25
                    }}
                  ></FeatherIcon>
                  <Sair>Sair</Sair>
                </Icon2Row>
              </Group30>
            </Group33>
          </Rect5StackStack>
        </Group34>
        <Rect>
          <Rect2></Rect2>
          <Rect3></Rect3>
        </Rect>
        <Group>
          <ImageRow>
            <Image
              src={require("../assets/images/8c4f7617-8963-4c00-b5ae-44c1e2bfe4df_200x2001.png")}
            ></Image>
            <PragasTracker>Pragas Tracker</PragasTracker>
          </ImageRow>
        </Group>
      </Group34Stack>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  background-color: rgba(50,104,171,1);
  border-width: 0px;
  border-color: #000000;
  flex-direction: column;
  border-style: solid;
  height: 100vh;
  width: 100vw;
`;

const Group34 = styled.div`
  top: 0px;
  left: 8px;
  width: 1302px;
  height: 700px;
  position: absolute;
  flex-direction: column;
  display: flex;
`;

const Rect5 = styled.div`
  top: 212px;
  left: 0px;
  width: 297px;
  height: 36px;
  position: absolute;
  background-color: rgba(185,235,197,1);
  border-radius: 17px;
`;

const Rect4 = styled.div`
  top: 0px;
  left: 262px;
  width: 1040px;
  height: 700px;
  position: absolute;
  background-color: rgba(185,235,197,1);
  border-radius: 17px;
  flex-direction: row;
  display: flex;
  box-shadow: 3px 3px 50px  1px rgba(185,235,197,1) ;
`;

const Rect6 = styled.div`
  width: 410px;
  height: 680px;
  background-color: rgba(243,241,241,1);
  border-radius: 17px;
  flex-direction: column;
  display: flex;
  box-shadow: 3px 3px 50px  1px rgba(243,241,241,1) ;
`;

const Group55 = styled.div`
  width: 390px;
  height: 656px;
  flex-direction: column;
  display: flex;
  margin-top: 13px;
  margin-left: 9px;
`;

const BancoDeDados2 = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 700;
  color: #121212;
  font-size: 30px;
`;

const Group54 = styled.div`
  width: 390px;
  height: 300px;
  flex-direction: column;
  display: flex;
  margin-top: 12px;
`;

const Rect30 = styled.div`
  width: 390px;
  height: 300px;
  background-color: #E6E6E6;
  border-radius: 8px;
  flex-direction: column;
  display: flex;
`;

const PastasDeDataset = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 700;
  color: #121212;
  font-size: 17px;
  margin-top: 11px;
  margin-left: 16px;
`;

const Group48 = styled.div`
  width: 300px;
  height: 131px;
  flex-direction: row;
  display: flex;
  margin-top: 6px;
  margin-left: 22px;
`;

const Group46 = styled.div`
  width: 96px;
  height: 129px;
  flex-direction: column;
  display: flex;
`;

const Blissus = styled.span`
  font-family: Alegreya Sans SC;
  top: 110px;
  left: 24px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 16px;
`;

const Icon15Stack = styled.div`
  width: 96px;
  height: 129px;
  position: relative;
`;

const Group47 = styled.div`
  width: 96px;
  height: 131px;
  flex-direction: column;
  display: flex;
  margin-left: 29px;
`;

const Cigarrinha = styled.span`
  font-family: Alegreya Sans SC;
  top: 112px;
  left: 10px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 16px;
`;

const Icon17Stack = styled.div`
  width: 96px;
  height: 131px;
  position: relative;
`;

const Group46Row = styled.div`
  height: 131px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
`;

const Group53 = styled.div`
  width: 390px;
  height: 301px;
  flex-direction: column;
  display: flex;
  margin-top: 7px;
`;

const Rect31 = styled.div`
  width: 390px;
  height: 301px;
  background-color: #E6E6E6;
  border-radius: 8px;
  flex-direction: column;
  display: flex;
`;

const PastasDeValidacao = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 700;
  color: #121212;
  font-size: 17px;
  margin-top: 10px;
  margin-left: 16px;
`;

const Group49 = styled.div`
  top: 0px;
  left: 0px;
  width: 165px;
  height: 119px;
  position: absolute;
  flex-direction: row;
  display: flex;
`;

const Icon19Row = styled.div`
  height: 120px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
`;

const Group45 = styled.div`
  top: 108px;
  left: 12px;
  width: 73px;
  height: 19px;
  position: absolute;
  flex-direction: column;
  display: flex;
`;

const Validation = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 16px;
`;

const Group49Stack = styled.div`
  width: 165px;
  height: 127px;
  margin-top: 10px;
  margin-left: 22px;
  position: relative;
`;

const Group52 = styled.div`
  width: 605px;
  height: 679px;
  flex-direction: column;
  display: flex;
  margin-left: 10px;
  margin-top: 1px;
`;

const Rect21 = styled.div`
  width: 605px;
  height: 679px;
  background-color: rgba(243,241,241,1);
  border-radius: 17px;
  flex-direction: column;
  display: flex;
  box-shadow: 3px 3px 50px  1px rgba(243,241,241,1) ;
`;

const Group50 = styled.div`
  width: 580px;
  height: 423px;
  flex-direction: column;
  display: flex;
  margin-top: 12px;
  margin-left: 12px;
`;

const Rect29 = styled.div`
  width: 580px;
  height: 423px;
  background-color: #E6E6E6;
  border-radius: 10px;
  flex-direction: column;
  display: flex;
`;

const ImagensDaPasta = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 700;
  color: #121212;
  font-size: 17px;
  margin-top: 13px;
  margin-left: 14px;
`;

const Group43 = styled.div`
  width: 533px;
  height: 354px;
  flex-direction: column;
  display: flex;
  margin-top: 11px;
  margin-left: 23px;
`;

const Group40 = styled.div`
  width: 532px;
  height: 100px;
  flex-direction: row;
  display: flex;
  margin-left: 1px;
`;

const Icon10Row = styled.div`
  height: 100px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
`;

const Group41 = styled.div`
  width: 532px;
  height: 100px;
  flex-direction: row;
  display: flex;
  margin-top: 27px;
  margin-left: 1px;
`;

const Icon26Row = styled.div`
  height: 100px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
`;

const Group42 = styled.div`
  width: 532px;
  height: 100px;
  flex-direction: row;
  display: flex;
  margin-top: 27px;
`;

const Icon30Row = styled.div`
  height: 100px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
`;

const Group51 = styled.div`
  width: 580px;
  height: 149px;
  flex-direction: column;
  display: flex;
  margin-top: 11px;
  margin-left: 13px;
`;

const Rect32 = styled.div`
  width: 580px;
  height: 149px;
  background-color: #E6E6E6;
  border-radius: 10px;
  flex-direction: column;
  display: flex;
`;

const AdicionarImagens = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 700;
  color: #121212;
  font-size: 17px;
  margin-top: 10px;
  margin-left: 13px;
`;

const Group44 = styled.div`
  width: 534px;
  height: 100px;
  flex-direction: row;
  display: flex;
  margin-top: 4px;
  margin-left: 20px;
`;

const Icon21Row = styled.div`
  height: 100px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
`;

const Group39 = styled.div`
  width: 265px;
  height: 36px;
  flex-direction: row;
  display: flex;
  margin-top: 23px;
  margin-left: 326px;
`;

const MaterialButtonPinkRow = styled.div`
  height: 36px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
`;

const Rect6Row = styled.div`
  height: 680px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: 6px;
  margin-left: 9px;
  margin-top: 10px;
`;

const Group8 = styled.div`
  top: 81px;
  left: 12px;
  width: 222px;
  height: 263px;
  position: absolute;
  flex-direction: column;
  display: flex;
`;

const Group2 = styled.div`
  width: 133px;
  height: 27px;
  flex-direction: row;
  display: flex;
`;

const Text = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 20px;
  margin-left: 13px;
  margin-top: 2px;
`;

const Icon4Row = styled.div`
  height: 27px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
`;

const Group3 = styled.div`
  width: 115px;
  height: 28px;
  flex-direction: row;
  display: flex;
  margin-top: 17px;
  margin-left: 1px;
`;

const Text2 = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 20px;
  margin-left: 13px;
  margin-top: 4px;
`;

const Icon5Row = styled.div`
  height: 28px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: 1px;
`;

const Group4 = styled.div`
  width: 170px;
  height: 27px;
  flex-direction: row;
  display: flex;
  margin-top: 18px;
  margin-left: 2px;
`;

const Recomendacoes = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 20px;
  margin-left: 13px;
  margin-top: 1px;
`;

const Icon6Row = styled.div`
  height: 27px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: -1px;
`;

const Group5 = styled.div`
  width: 172px;
  height: 27px;
  flex-direction: row;
  display: flex;
  margin-top: 20px;
  margin-left: 1px;
`;

const BancoDeDados = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 20px;
  margin-left: 13px;
  margin-top: 2px;
`;

const Icon8Row = styled.div`
  height: 27px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: 1px;
`;

const Group6 = styled.div`
  width: 170px;
  height: 25px;
  flex-direction: row;
  display: flex;
  margin-top: 22px;
`;

const Classificadores = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 20px;
  margin-left: 13px;
  margin-top: 1px;
`;

const Icon9Row = styled.div`
  height: 25px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: 1px;
`;

const Group7 = styled.div`
  width: 221px;
  height: 27px;
  flex-direction: row;
  display: flex;
  margin-top: 25px;
  margin-left: 1px;
`;

const ImagensClassifica = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 20px;
  margin-left: 12px;
  margin-top: 1px;
`;

const Icon7Row = styled.div`
  height: 27px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
`;

const Rect5Stack = styled.div`
  top: 0px;
  left: 0px;
  width: 1302px;
  height: 700px;
  position: absolute;
`;

const Group33 = styled.div`
  top: 496px;
  left: 23px;
  width: 193px;
  height: 158px;
  position: absolute;
  flex-direction: column;
  display: flex;
`;

const BemvindoAmaury = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 25px;
`;

const Group32 = styled.div`
  width: 175px;
  height: 27px;
  flex-direction: row;
  display: flex;
  margin-top: 17px;
  margin-left: 6px;
`;

const CadastrarAdmin = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 20px;
  margin-left: 12px;
  margin-top: 2px;
`;

const Icon3Row = styled.div`
  height: 27px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
`;

const Group31 = styled.div`
  width: 157px;
  height: 25px;
  flex-direction: row;
  display: flex;
  margin-top: 16px;
  margin-left: 6px;
`;

const Configuracoes = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 20px;
  margin-left: 7px;
  margin-top: 1px;
`;

const IconRow = styled.div`
  height: 25px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: 1px;
`;

const Group30 = styled.div`
  width: 63px;
  height: 25px;
  flex-direction: row;
  display: flex;
  margin-top: 18px;
  margin-left: 6px;
`;

const Sair = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 20px;
  margin-left: 4px;
  margin-top: 1px;
`;

const Icon2Row = styled.div`
  height: 25px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: -1px;
`;

const Rect5StackStack = styled.div`
  width: 1302px;
  height: 700px;
  position: relative;
`;

const Rect = styled.div`
  left: 0px;
  width: 250px;
  height: 700px;
  position: absolute;
  background-color: rgba(230,230, 230,0.8);
  border-radius: 17px;
  flex-direction: column;
  opacity: 0.7;
  top: 0px;
  display: flex;
  box-shadow: 3px 3px 50px  1px rgba(185,235,197,1) ;
`;

const Rect2 = styled.div`
  flex: 0.67 1 0%;
  background-color: rgba(221, 221, 221,0);
  display: flex;
  flex-direction: column;
`;

const Rect3 = styled.div`
  flex: 0.32999999999999996 1 0%;
  background-color: rgba(246, 246, 246,1);
  margin: 5px;
  padding: 0px;
  border-width: -1px;
  border-color: #000000;
  border-radius: 17px;
  border-style: solid;
  display: flex;
  flex-direction: column;
`;

const Group = styled.div`
  top: 14px;
  left: 4px;
  width: 240px;
  height: 32px;
  position: absolute;
  overflow: visible;
  flex-direction: row;
  display: flex;
`;

const Image = styled.img`
  width: 100%;
  height: 41px;
  object-fit: contain;
`;

const PragasTracker = styled.span`
  font-family: Alegreya Sans SC;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 30px;
  margin-top: 2px;
`;

const ImageRow = styled.div`
  height: 41px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: 5px;
`;

const Group34Stack = styled.div`
  width: 1310px;
  height: 700px;
  margin-top: 34px;
  margin-left: 30px;
  position: relative;
`;

export default Recomendacao1;
