import React, { Component } from "react";
import styled, { css } from "styled-components";
import MaterialIconTextbox from "../components/MaterialIconTextbox";
import MaterialIconTextbox1 from "../components/MaterialIconTextbox1";
import MaterialButtonPrimary from "../components/MaterialButtonPrimary";

function Login(props) {
  return (
    <Container>
      <RectStack>
        <Rect>
          <Rect2></Rect2>
          <Rect3></Rect3>
        </Rect>
        <MaterialIconTextbox
          inputStyle="Label"
          style={{
            height: 60,
            width: 375,
            position: "absolute",
            left: 657,
            top: 146,
            backgroundColor: "rgba(243,241,241,1)"
          }}
          inputStyle="E-mail"
        ></MaterialIconTextbox>
        <MaterialIconTextbox1
          inputStyle="Label"
          style={{
            height: 60,
            width: 375,
            position: "absolute",
            backgroundColor: "rgba(243,241,241,1)",
            left: 657,
            top: 236
          }}
          inputStyle=" Senha"
        ></MaterialIconTextbox1>
        <MaterialButtonPrimary
          style={{
            height: 45,
            width: 375,
            position: "absolute",
            left: 657,
            top: 346
          }}
          caption=" ENTRAR"
        ></MaterialButtonPrimary>
        <Image src={require("../assets/images/Ufrr_logo.png")}></Image>
        <Image2 src={require("../assets/images/image_R3DO..png")}></Image2>
        <Image3 src={require("../assets/images/layout_set_logo.png")}></Image3>
        <Image4
          src={require("../assets/images/8c4f7617-8963-4c00-b5ae-44c1e2bfe4df_200x200.png")}
        ></Image4>
        <Text>LOGIN</Text>
        <S2>Esqueci minha senha !</S2>
        <CliqueAqui>Clique aqui</CliqueAqui>
      </RectStack>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  background-color: rgba(50,104,171,1);
  flex-direction: column;
  height: 100vh;
  width: 100vw;
`;

const Rect = styled.div`
  width: 1120px;
  height: 460px;
  position: absolute;
  background-color: #E6E6E6;
  flex-direction: row;
  overflow: visible;
  left: 0px;
  top: 0px;
  opacity: 0.75;
  display: flex;
  box-shadow: 3px 3px 50px  1px rgba(185,235,197,1) ;
`;

const Rect2 = styled.div`
  flex: 0.5 1 0%;
  background-color: rgba(220, 220, 220,1);
  margin: 0px;
  display: flex;
  flex-direction: column;
`;

const Rect3 = styled.div`
  flex: 0.5 1 0%;
  background-color: rgba(234, 234, 234,1);
  margin: 0px;
  padding: 0px;
  display: flex;
  flex-direction: column;
`;

const Image = styled.img`
  top: 329px;
  left: 57px;
  width: 110px;
  height: 96px;
  position: absolute;
  object-fit: contain;
`;

const Image2 = styled.img`
  top: 330px;
  left: 217px;
  width: 110px;
  height: 96px;
  position: absolute;
  object-fit: contain;
`;

const Image3 = styled.img`
  top: 330px;
  left: 382px;
  width: 110px;
  height: 96px;
  position: absolute;
  object-fit: contain;
`;

const Image4 = styled.img`
  top: 66px;
  left: 177px;
  width: 205px;
  height: 200px;
  position: absolute;
  object-fit: contain;
`;

const Text = styled.span`
  font-family: Alegreya Sans SC;
  left: 792px;
  position: absolute;
  font-style: normal;
  font-weight: 700;
  color: #121212;
  font-size: 40px;
  top: 58px;
`;

const S2 = styled.span`
  font-family: Roboto;
  top: 406px;
  left: 737px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: #121212;
`;

const CliqueAqui = styled.span`
  font-family: Roboto;
  top: 406px;
  left: 883px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: #121212;
`;

const RectStack = styled.div`
  width: 1120px;
  height: 460px;
  margin-top: 154px;
  margin-left: 123px;
  position: relative;
`;

export default Login;
