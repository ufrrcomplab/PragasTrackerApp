import React, { Component } from "react";
import styled, { css } from "styled-components";

function MaterialButtonPrimary(props) {
  return (
    <Container {...props}>
      <Caption>{props.caption || "BUTTON"}</Caption>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  background-color: rgba(50,104,171,1);
  justify-content: center;
  align-items: center;
  flex-direction: row;
  border-radius: 17px;
  min-width: 88px;
  padding-left: 16px;
  padding-right: 16px;
  border-width: 0px;
  border-color: #000000;
  border-style: solid;
  box-shadow: 0px 1px 5px  0.35px #000 ;
`;

const Caption = styled.span`
  font-family: Alegreya Sans SC;
  color: rgba(243,241,241,1);
  font-size: 22px;
  font-weight: 700;
  text-align: center;
`;

export default MaterialButtonPrimary;
