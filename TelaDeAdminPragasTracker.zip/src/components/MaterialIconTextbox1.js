import React, { Component } from "react";
import styled, { css } from "styled-components";
import MaterialCommunityIconsIcon from "react-native-vector-icons/dist/MaterialCommunityIcons";

function MaterialIconTextbox1(props) {
  return (
    <Container {...props}>
      <MaterialCommunityIconsIcon
        name="onepassword"
        style={{
          color: "#616161",
          fontSize: 24,
          paddingLeft: 8
        }}
      ></MaterialCommunityIconsIcon>
      <InputStyle placeholder={props.inputStyle || "Label"}></InputStyle>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  background-color: transparent;
  flex-direction: row;
  align-items: center;
  border-width: 3px;
  border-color: rgba(50,104,171,1);
  border-radius: 17px;
  border-style: solid;
`;

const InputStyle = styled.input`
  font-family: Alegreya Sans SC;
  color: #000;
  margin-left: 16px;
  padding-right: 5px;
  font-size: 20px;
  align-self: stretch;
  flex: 1 1 0%;
  line-height: 16px;
  border-bottom-width: 1px;
  border-color: #D9D5DC;
  padding-top: 14px;
  padding-bottom: 8px;
  border: none;
  background: transparent;
  display: flex;
  flex-direction: column;
`;

export default MaterialIconTextbox1;
