import React, { Component } from "react";
import styled, { css } from "styled-components";

function MaterialButtonPrimary2(props) {
  return (
    <Container {...props}>
      <Button>{props.button || "BUTTON"}</Button>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  background-color: rgba(50,104,171,1);
  justify-content: center;
  align-items: center;
  flex-direction: row;
  border-radius: 5px;
  min-width: 88px;
  padding-left: 16px;
  padding-right: 16px;
  box-shadow: 0px 1px 5px  0.35px #000 ;
`;

const Button = styled.span`
  font-family: Alegreya Sans SC;
  color: #fff;
  font-size: 22px;
  text-align: center;
`;

export default MaterialButtonPrimary2;
