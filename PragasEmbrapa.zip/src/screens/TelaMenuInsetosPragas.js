import React, { Component } from "react";
import {
  StyleSheet,
  View,
  StatusBar,
  Text,
  ScrollView,
  Image
} from "react-native";
import CupertinoSegmentWithTwoTabs1 from "../components/CupertinoSegmentWithTwoTabs1";
import MaterialCommunityIconsIcon from "react-native-vector-icons/MaterialCommunityIcons";
import CupertinoButtonBlueTextColor from "../components/CupertinoButtonBlueTextColor";
import Data from "../components/Data";
import Hora from "../components/Hora";
import HistClass from "../components/HistClass";
import MaterialHeader1 from "../components/MaterialHeader1";

function TelaMenuInsetosPragas(props) {
  return (
    <View style={styles.container}>
      <StatusBar
        animated
        barStyle="light-content"
        backgroundColor="rgba(50,104,171,1)"
      />
      <View style={styles.rectStack}>
        <View gradientImage="Gradient_P2Y2JpI.png" style={styles.rect}>
          <View
            gradientImage="Gradient_SlxZ4YP.png"
            style={styles.rect4}
          ></View>
          <View style={styles.cupertinoSegmentWithTwoTabs1Stack}>
            <CupertinoSegmentWithTwoTabs1
              titleLeft="Insetos-Pragas"
              titleRight="Doenças"
              style={styles.cupertinoSegmentWithTwoTabs1}
            ></CupertinoSegmentWithTwoTabs1>
            <MaterialCommunityIconsIcon
              name="alert-outline"
              style={styles.icon}
            ></MaterialCommunityIconsIcon>
          </View>
          <Text style={styles.loremIpsum}>
            Nosso algoritmo de classificação foi feita para{"\n"}reconhecer por
            enquanto as seguintes pragas:{"\n"}Blissus Puchellus e da
            Cigarrinha.
          </Text>
          <CupertinoButtonBlueTextColor
            button="Button"
            button="Iniciar "
            style={styles.cupertinoButtonBlueTextColor}
          ></CupertinoButtonBlueTextColor>
          <View style={styles.scrollArea}>
            <ScrollView
              gradientImage="Gradient_E1R6spA.png"
              horizontal={false}
              contentContainerStyle={styles.scrollArea_contentContainerStyle}
            >
              <View style={styles.rect6}>
                <View style={styles.image2Row}>
                  <Image
                    source={require("../assets/images/png-transparent-butterfly-blue-butterfly-blue-brush-footed-butterfly-insects1.png")}
                    resizeMode="stretch"
                    style={styles.image2}
                  ></Image>
                  <View style={styles.data2RowColumn}>
                    <View style={styles.data2Row}>
                      <Data style={styles.data2}></Data>
                      <Hora loremIpsum="15 :39" style={styles.hora2}></Hora>
                    </View>
                    <Text style={styles.blissusPulch1}>Blissus Pulch</Text>
                  </View>
                  <View style={styles.icon2Column}>
                    <MaterialCommunityIconsIcon
                      name="emoticon-sad"
                      style={styles.icon2}
                    ></MaterialCommunityIconsIcon>
                    <Text style={styles.loremIpsum1}>45 %</Text>
                  </View>
                </View>
              </View>
              <HistClass style={styles.histClass1}></HistClass>
              <View style={styles.rect5}>
                <View style={styles.image1Row}>
                  <Image
                    source={require("../assets/images/png-transparent-butterfly-blue-butterfly-blue-brush-footed-butterfly-insects1.png")}
                    resizeMode="stretch"
                    style={styles.image1}
                  ></Image>
                  <View style={styles.data1RowColumn}>
                    <View style={styles.data1Row}>
                      <Data style={styles.data1}></Data>
                      <Hora loremIpsum="15 :39" style={styles.hora1}></Hora>
                      <MaterialCommunityIconsIcon
                        name="emoticon-sad"
                        style={styles.icon1}
                      ></MaterialCommunityIconsIcon>
                    </View>
                    <Text style={styles.desconhecida}>Desconhecida</Text>
                  </View>
                </View>
              </View>
            </ScrollView>
          </View>
          <Text style={styles.historico1}>HISTORICO DE ATIVIDADES</Text>
        </View>
        <MaterialHeader1
          leftIconButton="Login"
          title="Pragas Tracker"
          style={styles.materialHeader1}
        ></MaterialHeader1>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    borderWidth: 0,
    borderColor: "rgba(133,161,238,1)",
    borderBottomRightRadius: 0,
    borderBottomLeftRadius: 0,
    backgroundColor: "rgba(243,241,241,1)",
    borderStyle: "solid"
  },
  rect: {
    borderWidth: 5,
    borderColor: "rgba(50,104,171,1)",
    borderStyle: "solid",
    width: 361,
    height: 661,
    position: "absolute",
    top: 57,
    left: 0,
    borderRadius: 6,
    backgroundColor: "rgba(243,241,241,1)"
  },
  rect4: {
    flex: 0.44,
    backgroundColor: "rgba(243,241,241,1)"
  },
  cupertinoSegmentWithTwoTabs1: {
    height: 56,
    width: 350,
    position: "absolute",
    left: 0,
    top: 0
  },
  icon: {
    top: 55,
    position: "absolute",
    color: "rgba(50,104,171,1)",
    fontSize: 70,
    height: 76,
    width: 70,
    left: 140
  },
  cupertinoSegmentWithTwoTabs1Stack: {
    top: 5,
    left: 6,
    width: 350,
    height: 131,
    position: "absolute"
  },
  loremIpsum: {
    top: 144,
    position: "absolute",
    fontFamily: "alegreya-sans-sc-700",
    color: "#121212",
    textAlign: "center",
    fontSize: 17,
    opacity: 0.8,
    left: 10
  },
  cupertinoButtonBlueTextColor: {
    height: 44,
    width: 100,
    position: "absolute",
    borderWidth: 1,
    borderColor: "rgba(50,104,171,1)",
    top: 222,
    left: 131
  },
  scrollArea: {
    flex: 0.56,
    backgroundColor: "rgba(243,241,241,1)"
  },
  scrollArea_contentContainerStyle: {
    height: 365
  },
  rect6: {
    width: 318,
    height: 85,
    backgroundColor: "rgba(185,235,197,1)",
    borderWidth: 1,
    borderColor: "#000000",
    borderRadius: 10,
    marginTop: 148,
    marginLeft: 18
  },
  image2: {
    width: 62,
    height: 58,
    borderWidth: 1,
    borderColor: "#000000",
    borderRadius: 42,
    marginTop: 4
  },
  data2: {
    height: 24,
    width: 94,
    borderRadius: 3
  },
  hora2: {
    width: 48,
    height: 14,
    borderRadius: 3,
    marginLeft: 11,
    marginTop: 5
  },
  data2Row: {
    height: 24,
    flexDirection: "row",
    marginRight: 9
  },
  blissusPulch1: {
    fontFamily: "roboto-regular",
    color: "#121212",
    fontSize: 25,
    marginTop: 6,
    marginLeft: 8
  },
  data2RowColumn: {
    width: 162,
    marginLeft: 9,
    marginTop: 3
  },
  icon2: {
    color: "rgba(255,200,61,1)",
    fontSize: 27,
    height: 29,
    width: 27,
    marginLeft: 14
  },
  loremIpsum1: {
    fontFamily: "roboto-regular",
    color: "#121212",
    fontSize: 25,
    marginTop: 4
  },
  icon2Column: {
    width: 58,
    marginLeft: 3
  },
  image2Row: {
    height: 62,
    flexDirection: "row",
    marginTop: 10,
    marginLeft: 12,
    marginRight: 12
  },
  histClass1: {
    height: 85,
    width: 318,
    marginTop: -198,
    marginLeft: 18
  },
  rect5: {
    width: 318,
    height: 85,
    backgroundColor: "rgba(185,235,197,1)",
    borderWidth: 1,
    borderColor: "#000000",
    borderRadius: 10,
    marginTop: 142,
    marginLeft: 18
  },
  image1: {
    width: 62,
    height: 58,
    borderWidth: 1,
    borderColor: "#000000",
    borderRadius: 42,
    marginTop: 5
  },
  data1: {
    height: 24,
    width: 94,
    borderRadius: 3,
    marginTop: 4
  },
  hora1: {
    width: 48,
    height: 14,
    borderRadius: 3,
    marginLeft: 11,
    marginTop: 9
  },
  icon1: {
    color: "rgba(255,200,61,1)",
    fontSize: 27,
    width: 27,
    height: 29,
    marginLeft: 26
  },
  data1Row: {
    height: 29,
    flexDirection: "row"
  },
  desconhecida: {
    fontFamily: "roboto-regular",
    color: "#121212",
    fontSize: 25,
    marginLeft: 8
  },
  data1RowColumn: {
    width: 206,
    marginLeft: 9,
    marginBottom: 5
  },
  image1Row: {
    height: 63,
    flexDirection: "row",
    marginTop: 10,
    marginLeft: 12,
    marginRight: 29
  },
  historico1: {
    top: 292,
    position: "absolute",
    fontFamily: "alegreya-sc-700",
    color: "#121212",
    fontSize: 20,
    lineHeight: 30,
    textAlign: "center",
    opacity: 0.7,
    left: 56
  },
  materialHeader1: {
    height: 62,
    width: 360,
    position: "absolute",
    left: 1,
    top: 0
  },
  rectStack: {
    width: 361,
    height: 718,
    marginTop: 22,
    marginLeft: -1
  }
});

export default TelaMenuInsetosPragas;
