import React, { Component } from "react";
import { StyleSheet, View, StatusBar, Image, Text } from "react-native";
import CupertinoButtonInfo1 from "../components/CupertinoButtonInfo1";
import CupertinoButtonWarning from "../components/CupertinoButtonWarning";

function TelaLogin(props) {
  return (
    <View style={styles.container}>
      <StatusBar
        animated
        barStyle="light-content"
        backgroundColor="rgba(50,104,171,1)"
      />
      <View gradientImage="Gradient_P2Y2JpI.png" style={styles.rect}>
        <View style={styles.appLogoColumn}>
          <Image
            source={require("../assets/images/8c4f7617-8963-4c00-b5ae-44c1e2bfe4df_200x200.png")}
            resizeMode="contain"
            style={styles.appLogo}
          ></Image>
          <View style={styles.buttonSolicitarCadastroRow}>
            <CupertinoButtonInfo1
              style={styles.buttonSolicitarCadastro}
            ></CupertinoButtonInfo1>
            <View style={styles.buttonSolicitarCadastroFiller}></View>
            <CupertinoButtonWarning
              button="Gmail"
              style={styles.buttonEntrar}
            ></CupertinoButtonWarning>
          </View>
          <Image
            source={require("../assets/images/image_R3DO..png")}
            resizeMode="contain"
            style={styles.image}
          ></Image>
        </View>
        <View style={styles.emColaboracao1Stack}>
          <Text style={styles.emColaboracao1}>Em colaboração</Text>
          <Image
            source={require("../assets/images/Ufrr_logo.png")}
            resizeMode="contain"
            style={styles.ufrrLogo}
          ></Image>
          <Image
            source={require("../assets/images/layout_set_logo1.png")}
            resizeMode="contain"
            style={styles.embrapaLogo}
          ></Image>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    borderWidth: 0,
    borderColor: "rgba(133,161,238,1)",
    borderBottomRightRadius: 0,
    borderBottomLeftRadius: 0,
    backgroundColor: "rgba(243,241,241,1)",
    borderStyle: "solid"
  },
  rect: {
    width: 361,
    height: 740,
    borderWidth: 5,
    borderColor: "rgba(50,104,171,1)",
    borderRadius: 6,
    borderStyle: "solid",
    backgroundColor: "rgba(243,241,241,1)"
  },
  appLogo: {
    width: 201,
    height: 220,
    borderRadius: 100,
    marginLeft: 10
  },
  buttonSolicitarCadastro: {
    height: 46,
    width: 92
  },
  buttonSolicitarCadastroFiller: {
    flex: 1,
    flexDirection: "row"
  },
  buttonEntrar: {
    height: 46,
    width: 92
  },
  buttonSolicitarCadastroRow: {
    height: 46,
    flexDirection: "row",
    marginTop: 62
  },
  image: {
    height: 99,
    width: 86,
    marginTop: 199,
    marginLeft: 67
  },
  appLogoColumn: {
    marginTop: 88,
    marginLeft: 70,
    marginRight: 71
  },
  emColaboracao1: {
    top: 43,
    position: "absolute",
    fontFamily: "alegreya-sc-500",
    color: "rgba(255,255,255,1)",
    fontSize: 20,
    textAlign: "center",
    lineHeight: 20,
    bottom: 49,
    opacity: 0.5,
    left: 92
  },
  ufrrLogo: {
    top: 0,
    left: 0,
    width: 103,
    height: 92,
    position: "absolute"
  },
  embrapaLogo: {
    top: 0,
    left: 230,
    width: 100,
    height: 92,
    position: "absolute"
  },
  emColaboracao1Stack: {
    width: 330,
    flex: 1,
    marginBottom: 125,
    marginTop: -191,
    marginLeft: 14
  }
});

export default TelaLogin;
