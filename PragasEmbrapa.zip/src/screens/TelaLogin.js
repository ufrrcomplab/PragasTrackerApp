import React, { Component } from "react";
import { StyleSheet, View, StatusBar, Text, Image } from "react-native";
import CupertinoButtonInfo1 from "../components/CupertinoButtonInfo1";
import CupertinoButtonWarning from "../components/CupertinoButtonWarning";

function TelaLogin(props) {
  return (
    <View style={styles.container}>
      <StatusBar
        animated
        barStyle="light-content"
        backgroundColor="rgba(50,104,171,1)"
      />
      <View gradientImage="Gradient_P2Y2JpI.png" style={styles.rect}>
        <View style={styles.emColaboracao1Stack}>
          <Text style={styles.emColaboracao1}>Em colaboração</Text>
          <View style={styles.group4}>
            <View style={styles.group3}>
              <Image
                source={require("../assets/images/8c4f7617-8963-4c00-b5ae-44c1e2bfe4df_200x200.png")}
                resizeMode="contain"
                style={styles.appLogo}
              ></Image>
              <View style={styles.group2}>
                <CupertinoButtonInfo1
                  style={styles.buttonSolicitarCadastro}
                ></CupertinoButtonInfo1>
                <View style={styles.buttonSolicitarCadastroFiller}></View>
                <CupertinoButtonWarning
                  button="Gmail"
                  style={styles.buttonEntrar}
                ></CupertinoButtonWarning>
              </View>
            </View>
            <View style={styles.group}>
              <Image
                source={require("../assets/images/image_R3DO..png")}
                resizeMode="contain"
                style={styles.image}
              ></Image>
              <View style={styles.ufrrLogoRow}>
                <Image
                  source={require("../assets/images/Ufrr_logo.png")}
                  resizeMode="contain"
                  style={styles.ufrrLogo}
                ></Image>
                <Image
                  source={require("../assets/images/layout_set_logo1.png")}
                  resizeMode="contain"
                  style={styles.embrapaLogo}
                ></Image>
              </View>
            </View>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    borderWidth: 0,
    borderColor: "rgba(133,161,238,1)",
    borderBottomRightRadius: 0,
    borderBottomLeftRadius: 0,
    backgroundColor: "rgba(243,241,241,1)",
    borderStyle: "solid"
  },
  rect: {
    width: 361,
    height: 740,
    borderWidth: 5,
    borderColor: "rgba(50,104,171,1)",
    borderRadius: 6,
    borderStyle: "solid",
    backgroundColor: "rgba(243,241,241,1)"
  },
  emColaboracao1: {
    top: 478,
    position: "absolute",
    fontFamily: "alegreya-sc-500",
    color: "rgba(255,255,255,1)",
    fontSize: 20,
    textAlign: "center",
    lineHeight: 20,
    bottom: 148,
    opacity: 0.5,
    left: 92
  },
  group4: {
    top: 0,
    left: 0,
    width: 330,
    height: 626,
    position: "absolute"
  },
  group3: {
    width: 220,
    height: 328,
    marginLeft: 56
  },
  appLogo: {
    width: 201,
    height: 220,
    borderRadius: 100,
    marginLeft: 10
  },
  group2: {
    width: 220,
    height: 46,
    flexDirection: "row",
    marginTop: 62
  },
  buttonSolicitarCadastro: {
    height: 46,
    width: 92
  },
  buttonSolicitarCadastroFiller: {
    flex: 1,
    flexDirection: "row"
  },
  buttonEntrar: {
    height: 46,
    width: 92
  },
  group: {
    width: 330,
    height: 191,
    flexDirection: "row",
    marginTop: 107
  },
  image: {
    height: 99,
    width: 86,
    marginLeft: 123,
    marginTop: 92
  },
  ufrrLogo: {
    width: 103,
    height: 92
  },
  embrapaLogo: {
    width: 100,
    height: 92,
    marginLeft: 127
  },
  ufrrLogoRow: {
    height: 92,
    flexDirection: "row",
    flex: 1,
    marginLeft: -209
  },
  emColaboracao1Stack: {
    width: 330,
    flex: 1,
    marginBottom: 26,
    marginTop: 88,
    marginLeft: 14
  }
});

export default TelaLogin;
