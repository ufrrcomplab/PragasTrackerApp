import React, { Component } from "react";
import {
  StyleSheet,
  View,
  StatusBar,
  TouchableOpacity,
  Text,
  ScrollView
} from "react-native";
import MaterialHeader11 from "../components/MaterialHeader11";
import FontAwesomeIcon from "react-native-vector-icons/FontAwesome";
import CupertinoButtonLight from "../components/CupertinoButtonLight";

function TelaDeOutrasPragas(props) {
  return (
    <View style={styles.container}>
      <StatusBar
        animated
        barStyle="light-content"
        backgroundColor="rgba(50,104,171,1)"
      />
      <View style={styles.group7}>
        <View style={styles.button2Stack}>
          <TouchableOpacity
            gradientImage="Gradient_P2Y2JpI.png"
            style={styles.button2}
          >
            <View style={styles.rect2}></View>
            <MaterialHeader11
              title="Pragas Tracker"
              style={styles.materialHeader11}
            ></MaterialHeader11>
            <Text style={styles.pragas}>PRAGAS</Text>
            <View style={styles.rect3}></View>
          </TouchableOpacity>
          <View style={styles.scrollArea}>
            <ScrollView
              horizontal={false}
              contentContainerStyle={styles.scrollArea_contentContainerStyle}
            >
              <View style={styles.group}>
                <View style={styles.rect4}>
                  <Text style={styles.historico1}>
                    Cigarrinhas -Das-Pastagens
                  </Text>
                  <View style={styles.scrollArea2}>
                    <ScrollView
                      horizontal={true}
                      contentContainerStyle={
                        styles.scrollArea2_contentContainerStyle
                      }
                    >
                      <View style={styles.icon2Row}>
                        <FontAwesomeIcon
                          name="image"
                          style={styles.icon2}
                        ></FontAwesomeIcon>
                        <FontAwesomeIcon
                          name="image"
                          style={styles.icon6}
                        ></FontAwesomeIcon>
                        <FontAwesomeIcon
                          name="image"
                          style={styles.icon5}
                        ></FontAwesomeIcon>
                        <FontAwesomeIcon
                          name="image"
                          style={styles.icon7}
                        ></FontAwesomeIcon>
                        <FontAwesomeIcon
                          name="image"
                          style={styles.icon8}
                        ></FontAwesomeIcon>
                        <FontAwesomeIcon
                          name="image"
                          style={styles.icon9}
                        ></FontAwesomeIcon>
                      </View>
                    </ScrollView>
                  </View>
                  <CupertinoButtonLight
                    button="ESCOLHER"
                    style={styles.cupertinoButtonLight}
                  ></CupertinoButtonLight>
                </View>
              </View>
              <View style={styles.group5}>
                <View style={styles.rect5}>
                  <Text style={styles.cupins}>Cupins</Text>
                  <View style={styles.scrollArea3}>
                    <ScrollView
                      horizontal={true}
                      contentContainerStyle={
                        styles.scrollArea3_contentContainerStyle
                      }
                    >
                      <View style={styles.icon10Row}>
                        <FontAwesomeIcon
                          name="image"
                          style={styles.icon10}
                        ></FontAwesomeIcon>
                        <FontAwesomeIcon
                          name="image"
                          style={styles.icon12}
                        ></FontAwesomeIcon>
                        <FontAwesomeIcon
                          name="image"
                          style={styles.icon11}
                        ></FontAwesomeIcon>
                        <FontAwesomeIcon
                          name="image"
                          style={styles.icon13}
                        ></FontAwesomeIcon>
                        <FontAwesomeIcon
                          name="image"
                          style={styles.icon14}
                        ></FontAwesomeIcon>
                        <FontAwesomeIcon
                          name="image"
                          style={styles.icon15}
                        ></FontAwesomeIcon>
                      </View>
                    </ScrollView>
                  </View>
                  <CupertinoButtonLight
                    button="ESCOLHER"
                    style={styles.cupertinoButtonLight1}
                  ></CupertinoButtonLight>
                </View>
              </View>
              <View style={styles.group6}>
                <View style={styles.rect6}>
                  <Text style={styles.c34}>Lagartas-Desfolhadoras</Text>
                  <View style={styles.scrollArea4}>
                    <ScrollView
                      horizontal={true}
                      contentContainerStyle={
                        styles.scrollArea4_contentContainerStyle
                      }
                    >
                      <View style={styles.icon16Row}>
                        <FontAwesomeIcon
                          name="image"
                          style={styles.icon16}
                        ></FontAwesomeIcon>
                        <FontAwesomeIcon
                          name="image"
                          style={styles.icon18}
                        ></FontAwesomeIcon>
                        <FontAwesomeIcon
                          name="image"
                          style={styles.icon17}
                        ></FontAwesomeIcon>
                        <FontAwesomeIcon
                          name="image"
                          style={styles.icon19}
                        ></FontAwesomeIcon>
                        <FontAwesomeIcon
                          name="image"
                          style={styles.icon20}
                        ></FontAwesomeIcon>
                        <FontAwesomeIcon
                          name="image"
                          style={styles.icon21}
                        ></FontAwesomeIcon>
                      </View>
                    </ScrollView>
                  </View>
                  <CupertinoButtonLight
                    button="ESCOLHER"
                    style={styles.cupertinoButtonLight2}
                  ></CupertinoButtonLight>
                </View>
              </View>
              <View style={styles.group3}>
                <View style={styles.rect7}>
                  <Text style={styles.historico4}>Cochonilha-Dos-Capins</Text>
                  <View style={styles.scrollArea5}>
                    <ScrollView
                      horizontal={true}
                      contentContainerStyle={
                        styles.scrollArea5_contentContainerStyle
                      }
                    >
                      <View style={styles.icon22Row}>
                        <FontAwesomeIcon
                          name="image"
                          style={styles.icon22}
                        ></FontAwesomeIcon>
                        <FontAwesomeIcon
                          name="image"
                          style={styles.icon24}
                        ></FontAwesomeIcon>
                        <FontAwesomeIcon
                          name="image"
                          style={styles.icon23}
                        ></FontAwesomeIcon>
                        <FontAwesomeIcon
                          name="image"
                          style={styles.icon25}
                        ></FontAwesomeIcon>
                        <FontAwesomeIcon
                          name="image"
                          style={styles.icon26}
                        ></FontAwesomeIcon>
                        <FontAwesomeIcon
                          name="image"
                          style={styles.icon27}
                        ></FontAwesomeIcon>
                      </View>
                    </ScrollView>
                  </View>
                  <CupertinoButtonLight
                    button="ESCOLHER"
                    style={styles.cupertinoButtonLight3}
                  ></CupertinoButtonLight>
                </View>
              </View>
              <View style={styles.group4}>
                <View style={styles.rect8}>
                  <Text style={styles.historico5}>Percevejo-Das-Gramíneas</Text>
                  <View style={styles.scrollArea6}>
                    <ScrollView
                      horizontal={true}
                      contentContainerStyle={
                        styles.scrollArea6_contentContainerStyle
                      }
                    >
                      <View style={styles.icon28Row}>
                        <FontAwesomeIcon
                          name="image"
                          style={styles.icon28}
                        ></FontAwesomeIcon>
                        <FontAwesomeIcon
                          name="image"
                          style={styles.icon30}
                        ></FontAwesomeIcon>
                        <FontAwesomeIcon
                          name="image"
                          style={styles.icon29}
                        ></FontAwesomeIcon>
                        <FontAwesomeIcon
                          name="image"
                          style={styles.icon31}
                        ></FontAwesomeIcon>
                        <FontAwesomeIcon
                          name="image"
                          style={styles.icon32}
                        ></FontAwesomeIcon>
                        <FontAwesomeIcon
                          name="image"
                          style={styles.icon33}
                        ></FontAwesomeIcon>
                      </View>
                    </ScrollView>
                  </View>
                  <CupertinoButtonLight
                    button="ESCOLHER"
                    style={styles.cupertinoButtonLight4}
                  ></CupertinoButtonLight>
                </View>
              </View>
            </ScrollView>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    borderWidth: 0,
    borderColor: "rgba(133,161,238,1)",
    borderBottomRightRadius: 0,
    borderBottomLeftRadius: 0,
    backgroundColor: "rgba(243,241,241,1)",
    borderStyle: "solid"
  },
  group7: {
    width: 361,
    height: 1920
  },
  button2: {
    width: 361,
    height: 740,
    position: "absolute",
    top: 0,
    left: 0,
    borderWidth: 5,
    borderColor: "rgba(50,104,171,1)",
    borderRadius: 6,
    borderStyle: "solid",
    backgroundColor: "rgba(243,241,241,1)"
  },
  rect2: {
    flex: 0.39,
    backgroundColor: "rgba(243,241,241,1)",
    margin: 0
  },
  materialHeader11: {
    height: 56,
    width: 360,
    position: "absolute",
    left: 0,
    top: 22
  },
  pragas: {
    position: "absolute",
    fontFamily: "alegreya-sc-700",
    color: "#121212",
    textAlign: "center",
    fontSize: 20,
    textDecorationLine: "underline",
    top: 85,
    left: 145
  },
  rect3: {
    flex: 0.61,
    backgroundColor: "rgba(243,241,241,1)",
    margin: 0
  },
  scrollArea: {
    top: 120,
    width: 320,
    height: 1800,
    position: "absolute",
    backgroundColor: "#E6E6E6",
    left: 21
  },
  scrollArea_contentContainerStyle: {
    height: 1800,
    width: 320
  },
  group: {
    width: 309,
    height: 235,
    marginTop: 21,
    marginLeft: 6
  },
  rect4: {
    width: 309,
    height: 235,
    backgroundColor: "rgba(243,241,241,1)"
  },
  historico1: {
    fontFamily: "alegreya-sc-700",
    color: "#121212",
    fontSize: 20,
    lineHeight: 30,
    textAlign: "center",
    opacity: 0.7,
    marginTop: 5,
    marginLeft: 26
  },
  scrollArea2: {
    width: 280,
    height: 140,
    backgroundColor: "rgba(230,230,230,1)",
    marginTop: 4,
    marginLeft: 15
  },
  scrollArea2_contentContainerStyle: {
    width: 820,
    height: 140,
    flexDirection: "row"
  },
  icon2: {
    color: "rgba(128,128,128,1)",
    fontSize: 100
  },
  icon6: {
    color: "rgba(128,128,128,1)",
    fontSize: 100,
    marginLeft: 28
  },
  icon5: {
    color: "rgba(128,128,128,1)",
    fontSize: 100,
    marginLeft: 31
  },
  icon7: {
    color: "rgba(128,128,128,1)",
    fontSize: 100,
    marginLeft: 31
  },
  icon8: {
    color: "rgba(128,128,128,1)",
    fontSize: 100,
    marginLeft: 35
  },
  icon9: {
    color: "rgba(128,128,128,1)",
    fontSize: 100,
    marginLeft: 33
  },
  icon2Row: {
    height: 100,
    flexDirection: "row",
    flex: 1,
    marginRight: -540,
    marginLeft: 20,
    marginTop: 20
  },
  cupertinoButtonLight: {
    height: 27,
    width: 130,
    borderWidth: 2,
    borderColor: "rgba(0,230,118,1)",
    borderRadius: 7,
    marginTop: 15,
    marginLeft: 90
  },
  group5: {
    width: 309,
    height: 235,
    marginTop: 24,
    marginLeft: 6
  },
  rect5: {
    width: 309,
    height: 235,
    backgroundColor: "rgba(243,241,241,1)"
  },
  cupins: {
    fontFamily: "alegreya-sc-700",
    color: "#121212",
    fontSize: 20,
    lineHeight: 30,
    textAlign: "center",
    opacity: 0.7,
    marginLeft: 124
  },
  scrollArea3: {
    width: 280,
    height: 140,
    backgroundColor: "rgba(230,230,230,1)",
    marginTop: 9,
    marginLeft: 15
  },
  scrollArea3_contentContainerStyle: {
    width: 820,
    height: 140,
    flexDirection: "row"
  },
  icon10: {
    color: "rgba(128,128,128,1)",
    fontSize: 100
  },
  icon12: {
    color: "rgba(128,128,128,1)",
    fontSize: 100,
    marginLeft: 28
  },
  icon11: {
    color: "rgba(128,128,128,1)",
    fontSize: 100,
    marginLeft: 31
  },
  icon13: {
    color: "rgba(128,128,128,1)",
    fontSize: 100,
    marginLeft: 31
  },
  icon14: {
    color: "rgba(128,128,128,1)",
    fontSize: 100,
    marginLeft: 35
  },
  icon15: {
    color: "rgba(128,128,128,1)",
    fontSize: 100,
    marginLeft: 33
  },
  icon10Row: {
    height: 100,
    flexDirection: "row",
    flex: 1,
    marginRight: -540,
    marginLeft: 20,
    marginTop: 20
  },
  cupertinoButtonLight1: {
    height: 27,
    width: 130,
    borderWidth: 2,
    borderColor: "rgba(0,230,118,1)",
    borderRadius: 7,
    marginTop: 15,
    marginLeft: 90
  },
  group6: {
    width: 309,
    height: 235,
    marginTop: 23,
    marginLeft: 6
  },
  rect6: {
    width: 309,
    height: 235,
    backgroundColor: "rgba(243,241,241,1)"
  },
  c34: {
    fontFamily: "alegreya-sc-700",
    color: "#121212",
    fontSize: 20,
    lineHeight: 30,
    textAlign: "center",
    opacity: 0.7,
    marginTop: 4,
    marginLeft: 40
  },
  scrollArea4: {
    width: 280,
    height: 140,
    backgroundColor: "rgba(230,230,230,1)",
    marginTop: 4,
    marginLeft: 15
  },
  scrollArea4_contentContainerStyle: {
    width: 820,
    height: 140,
    flexDirection: "row"
  },
  icon16: {
    color: "rgba(128,128,128,1)",
    fontSize: 100
  },
  icon18: {
    color: "rgba(128,128,128,1)",
    fontSize: 100,
    marginLeft: 28
  },
  icon17: {
    color: "rgba(128,128,128,1)",
    fontSize: 100,
    marginLeft: 31
  },
  icon19: {
    color: "rgba(128,128,128,1)",
    fontSize: 100,
    marginLeft: 31
  },
  icon20: {
    color: "rgba(128,128,128,1)",
    fontSize: 100,
    marginLeft: 35
  },
  icon21: {
    color: "rgba(128,128,128,1)",
    fontSize: 100,
    marginLeft: 33
  },
  icon16Row: {
    height: 100,
    flexDirection: "row",
    flex: 1,
    marginRight: -540,
    marginLeft: 20,
    marginTop: 20
  },
  cupertinoButtonLight2: {
    height: 27,
    width: 130,
    borderWidth: 2,
    borderColor: "rgba(0,230,118,1)",
    borderRadius: 7,
    marginTop: 15,
    marginLeft: 90
  },
  group3: {
    width: 309,
    height: 235,
    marginTop: 25,
    marginLeft: 6
  },
  rect7: {
    width: 309,
    height: 235,
    backgroundColor: "rgba(243,241,241,1)"
  },
  historico4: {
    fontFamily: "alegreya-sc-700",
    color: "#121212",
    fontSize: 20,
    lineHeight: 30,
    textAlign: "center",
    opacity: 0.7,
    marginTop: 5,
    marginLeft: 46
  },
  scrollArea5: {
    width: 280,
    height: 140,
    backgroundColor: "rgba(230,230,230,1)",
    marginTop: 4,
    marginLeft: 15
  },
  scrollArea5_contentContainerStyle: {
    width: 820,
    height: 140,
    flexDirection: "row"
  },
  icon22: {
    color: "rgba(128,128,128,1)",
    fontSize: 100
  },
  icon24: {
    color: "rgba(128,128,128,1)",
    fontSize: 100,
    marginLeft: 28
  },
  icon23: {
    color: "rgba(128,128,128,1)",
    fontSize: 100,
    marginLeft: 31
  },
  icon25: {
    color: "rgba(128,128,128,1)",
    fontSize: 100,
    marginLeft: 31
  },
  icon26: {
    color: "rgba(128,128,128,1)",
    fontSize: 100,
    marginLeft: 35
  },
  icon27: {
    color: "rgba(128,128,128,1)",
    fontSize: 100,
    marginLeft: 33
  },
  icon22Row: {
    height: 100,
    flexDirection: "row",
    flex: 1,
    marginRight: -540,
    marginLeft: 20,
    marginTop: 20
  },
  cupertinoButtonLight3: {
    height: 27,
    width: 130,
    borderWidth: 2,
    borderColor: "rgba(0,230,118,1)",
    borderRadius: 7,
    marginTop: 15,
    marginLeft: 90
  },
  group4: {
    width: 309,
    height: 235,
    marginTop: 24,
    marginLeft: 6
  },
  rect8: {
    width: 309,
    height: 235,
    backgroundColor: "rgba(243,241,241,1)"
  },
  historico5: {
    fontFamily: "alegreya-sc-700",
    color: "#121212",
    fontSize: 20,
    lineHeight: 30,
    textAlign: "center",
    opacity: 0.7,
    marginTop: 5,
    marginLeft: 36
  },
  scrollArea6: {
    width: 280,
    height: 140,
    backgroundColor: "rgba(230,230,230,1)",
    marginTop: 4,
    marginLeft: 15
  },
  scrollArea6_contentContainerStyle: {
    width: 820,
    height: 140,
    flexDirection: "row"
  },
  icon28: {
    color: "rgba(128,128,128,1)",
    fontSize: 100
  },
  icon30: {
    color: "rgba(128,128,128,1)",
    fontSize: 100,
    marginLeft: 28
  },
  icon29: {
    color: "rgba(128,128,128,1)",
    fontSize: 100,
    marginLeft: 31
  },
  icon31: {
    color: "rgba(128,128,128,1)",
    fontSize: 100,
    marginLeft: 31
  },
  icon32: {
    color: "rgba(128,128,128,1)",
    fontSize: 100,
    marginLeft: 35
  },
  icon33: {
    color: "rgba(128,128,128,1)",
    fontSize: 100,
    marginLeft: 33
  },
  icon28Row: {
    height: 100,
    flexDirection: "row",
    flex: 1,
    marginRight: -540,
    marginLeft: 20,
    marginTop: 20
  },
  cupertinoButtonLight4: {
    height: 27,
    width: 130,
    borderWidth: 2,
    borderColor: "rgba(0,230,118,1)",
    borderRadius: 7,
    marginTop: 15,
    marginLeft: 90
  },
  button2Stack: {
    width: 361,
    height: 1920
  }
});

export default TelaDeOutrasPragas;
