import React, { Component } from "react";
import { StyleSheet, View, StatusBar, Text } from "react-native";
import MaterialCommunityIconsIcon from "react-native-vector-icons/MaterialCommunityIcons";
import FontAwesomeIcon from "react-native-vector-icons/FontAwesome";
import CupertinoButtonDanger1 from "../components/CupertinoButtonDanger1";
import CupertinoButtonLight1 from "../components/CupertinoButtonLight1";
import CupertinoButtonSuccess2 from "../components/CupertinoButtonSuccess2";
import MaterialHeader11 from "../components/MaterialHeader11";

function TelaDeParaPragas1(props) {
  return (
    <View style={styles.container}>
      <StatusBar
        animated
        barStyle="light-content"
        backgroundColor="rgba(50,104,171,1)"
      />
      <View style={styles.group}>
        <View style={styles.rect1}>
          <MaterialCommunityIconsIcon
            name="alert-outline"
            style={styles.icon1}
          ></MaterialCommunityIconsIcon>
          <Text style={styles.novaTentativa}>NOVA TENTATIVA</Text>
          <View style={styles.loremIpsum1Row}>
            <Text style={styles.loremIpsum1}>
              Para uma nova tentativa{"\n"}aperta OK, caso queira {"\n"}
              Classificar manualmente {"\n"}Aperta CLASSIFICAR{"\n"}e aperta NÃO
              para voltar{"\n"}ao MENU PRINCIPAL.
            </Text>
            <FontAwesomeIcon
              name="repeat"
              style={styles.icon2}
            ></FontAwesomeIcon>
          </View>
          <View style={styles.group1}>
            <View style={styles.cupertinoButtonDanger1Row}>
              <CupertinoButtonDanger1
                caption="Button"
                button="NÃO "
                style={styles.cupertinoButtonDanger1}
              ></CupertinoButtonDanger1>
              <CupertinoButtonLight1
                button="CLASSIFICAR"
                style={styles.cupertinoButtonLight1}
              ></CupertinoButtonLight1>
              <CupertinoButtonSuccess2
                caption="Button"
                button="OK "
                style={styles.cupertinoButtonSuccess1}
              ></CupertinoButtonSuccess2>
            </View>
          </View>
        </View>
      </View>
      <MaterialHeader11
        title="Pragas Tracker"
        style={styles.materialHeader11}
      ></MaterialHeader11>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    borderWidth: 0,
    borderColor: "rgba(133,161,238,1)",
    borderBottomRightRadius: 0,
    borderBottomLeftRadius: 0,
    backgroundColor: "rgba(243,241,241,1)",
    borderStyle: "solid"
  },
  group: {
    width: 360,
    height: 556,
    marginTop: 120
  },
  rect1: {
    width: 360,
    height: 520,
    backgroundColor: "#E6E6E6"
  },
  icon1: {
    color: "rgba(217,48,37,1)",
    fontSize: 125,
    height: 136,
    width: 125,
    marginTop: 7,
    marginLeft: 119
  },
  novaTentativa: {
    fontFamily: "alegreya-sc-700",
    color: "rgba(217,48,37,1)",
    fontSize: 20,
    textAlign: "center",
    textDecorationLine: "underline",
    marginLeft: 101
  },
  loremIpsum1: {
    fontFamily: "alegreya-sans-sc-700",
    color: "#121212",
    textAlign: "center",
    fontSize: 25
  },
  icon2: {
    color: "rgba(50,104,171,1)",
    fontSize: 25,
    height: 25,
    width: 21,
    marginLeft: 1,
    marginTop: 153
  },
  loremIpsum1Row: {
    height: 180,
    flexDirection: "row",
    marginTop: 32,
    marginLeft: 41,
    marginRight: 19
  },
  group1: {
    width: 330,
    height: 41,
    flexDirection: "row",
    marginTop: 38,
    marginLeft: 15
  },
  cupertinoButtonDanger1: {
    height: 40,
    width: 80,
    backgroundColor: "rgba(217,48,37,1)",
    borderRadius: 6,
    marginTop: 1
  },
  cupertinoButtonLight1: {
    height: 40,
    width: 140,
    borderRadius: 7,
    borderWidth: 2,
    borderColor: "rgba(255,215,40,1)",
    marginLeft: 15,
    marginTop: 1
  },
  cupertinoButtonSuccess1: {
    height: 40,
    width: 80,
    borderWidth: 0,
    borderColor: "#000000",
    borderRadius: 7,
    marginLeft: 15
  },
  cupertinoButtonDanger1Row: {
    height: 41,
    flexDirection: "row",
    flex: 1
  },
  materialHeader11: {
    height: 56,
    width: 360,
    marginTop: -654
  }
});

export default TelaDeParaPragas1;
