import React, { Component } from "react";
import {
  StyleSheet,
  View,
  StatusBar,
  TouchableOpacity,
  Image
} from "react-native";
import MaterialHeader11 from "../components/MaterialHeader11";
import MaterialSpinner from "../components/MaterialSpinner";

function TelaDeEspera(props) {
  return (
    <View style={styles.container}>
      <StatusBar
        animated
        barStyle="light-content"
        backgroundColor="rgba(50,104,171,1)"
      />
      <TouchableOpacity
        gradientImage="Gradient_P2Y2JpI.png"
        style={styles.button2}
      >
        <View style={styles.rect2}></View>
        <MaterialHeader11
          title="Pragas Tracker"
          style={styles.materialHeader11}
        ></MaterialHeader11>
        <View style={styles.appLogo1Stack}>
          <Image
            source={require("../assets/images/8c4f7617-8963-4c00-b5ae-44c1e2bfe4df_200x200.png")}
            resizeMode="contain"
            style={styles.appLogo1}
          ></Image>
          <MaterialSpinner style={styles.materialSpinner}></MaterialSpinner>
        </View>
        <View style={styles.rect3}></View>
        <View style={styles.group}>
          <View style={styles.ufrrLogo1Row}>
            <Image
              source={require("../assets/images/Ufrr_logo.png")}
              resizeMode="contain"
              style={styles.ufrrLogo1}
            ></Image>
            <Image
              source={require("../assets/images/image_R3DO..png")}
              resizeMode="contain"
              style={styles.image1}
            ></Image>
          </View>
          <View style={styles.ufrrLogo1RowFiller}></View>
          <Image
            source={require("../assets/images/layout_set_logo1.png")}
            resizeMode="contain"
            style={styles.embrapaLogo1}
          ></Image>
        </View>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    borderWidth: 0,
    borderColor: "rgba(133,161,238,1)",
    borderBottomRightRadius: 0,
    borderBottomLeftRadius: 0,
    backgroundColor: "rgba(243,241,241,1)",
    borderStyle: "solid"
  },
  button2: {
    width: 360,
    height: 740,
    borderWidth: 5,
    borderColor: "rgba(50,104,171,1)",
    borderRadius: 6,
    borderStyle: "solid",
    backgroundColor: "rgba(243,241,241,1)"
  },
  rect2: {
    flex: 0.39,
    backgroundColor: "rgba(243,241,241,1)",
    margin: 0
  },
  materialHeader11: {
    height: 56,
    width: 360,
    position: "absolute",
    left: 0,
    top: 22
  },
  appLogo1: {
    width: 201,
    height: 220,
    position: "absolute",
    borderRadius: 100,
    left: 17,
    top: 0
  },
  materialSpinner: {
    width: 234,
    height: 215,
    position: "absolute",
    borderWidth: 1,
    borderColor: "rgba(50,104,171,1)",
    left: 0,
    top: 2
  },
  appLogo1Stack: {
    top: 260,
    left: 63,
    width: 234,
    height: 220,
    position: "absolute"
  },
  rect3: {
    flex: 0.61,
    backgroundColor: "rgba(243,241,241,1)",
    margin: 0
  },
  group: {
    top: 607,
    left: 17,
    width: 316,
    height: 84,
    position: "absolute",
    flexDirection: "row"
  },
  ufrrLogo1: {
    width: 99,
    height: 84
  },
  image1: {
    height: 84,
    width: 88,
    marginLeft: 20
  },
  ufrrLogo1Row: {
    height: 84,
    flexDirection: "row"
  },
  ufrrLogo1RowFiller: {
    flex: 1,
    flexDirection: "row"
  },
  embrapaLogo1: {
    width: 96,
    height: 84
  }
});

export default TelaDeEspera;
