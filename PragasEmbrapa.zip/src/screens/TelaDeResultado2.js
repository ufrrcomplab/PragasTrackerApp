import React, { Component } from "react";
import {
  StyleSheet,
  View,
  StatusBar,
  TouchableOpacity,
  Text
} from "react-native";
import MaterialHeader11 from "../components/MaterialHeader11";
import CupertinoButtonDanger1 from "../components/CupertinoButtonDanger1";
import Icon from "react-native-vector-icons/FontAwesome";
import CupertinoButtonSuccess2 from "../components/CupertinoButtonSuccess2";

function TelaDeResultado2(props) {
  return (
    <View style={styles.container}>
      <StatusBar
        animated
        barStyle="light-content"
        backgroundColor="rgba(50,104,171,1)"
      />
      <TouchableOpacity
        gradientImage="Gradient_P2Y2JpI.png"
        style={styles.button2}
      >
        <View style={styles.rect2}></View>
        <View style={styles.rect3}></View>
        <MaterialHeader11
          title="Pragas Tracker"
          style={styles.materialHeader11}
        ></MaterialHeader11>
        <Text style={styles.loremIpsum}>
          Para uma nova tentativa aperta OK, {"\n"}caso não queira, Aperta NÃO
          {"\n"} para voltar ao MENU PRINCIPAL.
        </Text>
        <Text style={styles.os}>
          Não foi possível reconhecer {"\n"}a foto tirada como um dos insetos
          {"\n"} de nosso banco de dados.
        </Text>
        <CupertinoButtonDanger1
          caption="NÃO"
          style={styles.cupertinoButtonDanger1}
        ></CupertinoButtonDanger1>
        <Icon name="times-rectangle-o" style={styles.icon9}></Icon>
        <Text style={styles.novaTentativa}>NOVA TENTATIVA</Text>
        <Text style={styles.resultado}>RESULTADO</Text>
        <CupertinoButtonSuccess2
          caption="OK"
          style={styles.cupertinoButtonSuccess2}
        ></CupertinoButtonSuccess2>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    borderWidth: 0,
    borderColor: "rgba(133,161,238,1)",
    borderBottomRightRadius: 0,
    borderBottomLeftRadius: 0,
    backgroundColor: "rgba(243,241,241,1)",
    borderStyle: "solid"
  },
  button2: {
    width: 361,
    height: 740,
    borderWidth: 5,
    borderColor: "rgba(50,104,171,1)",
    borderRadius: 6,
    borderStyle: "solid",
    backgroundColor: "rgba(243,241,241,1)"
  },
  rect2: {
    flex: 0.39,
    backgroundColor: "rgba(243,241,241,1)",
    margin: 0
  },
  rect3: {
    flex: 0.61,
    backgroundColor: "rgba(243,241,241,1)",
    margin: 0
  },
  materialHeader11: {
    height: 56,
    width: 360,
    position: "absolute",
    left: 0,
    top: 22
  },
  loremIpsum: {
    top: 500,
    position: "absolute",
    fontFamily: "alegreya-sans-sc-700",
    color: "#121212",
    fontSize: 22,
    textAlign: "center",
    left: 11
  },
  os: {
    position: "absolute",
    fontFamily: "alegreya-sans-sc-700",
    color: "#121212",
    textAlign: "center",
    fontSize: 20,
    left: 35,
    top: 334
  },
  cupertinoButtonDanger1: {
    height: 44,
    width: 100,
    position: "absolute",
    left: 41,
    top: 616,
    backgroundColor: "rgba(217,48,37,1)"
  },
  icon9: {
    top: 144,
    position: "absolute",
    color: "rgba(217,48,37,1)",
    fontSize: 170,
    height: 170,
    width: 170,
    left: 95
  },
  novaTentativa: {
    top: 449,
    position: "absolute",
    fontFamily: "alegreya-sc-700",
    color: "#121212",
    textAlign: "center",
    fontSize: 20,
    textDecorationLine: "underline",
    left: 101
  },
  resultado: {
    top: 101,
    position: "absolute",
    fontFamily: "alegreya-sc-700",
    color: "#121212",
    textAlign: "center",
    fontSize: 20,
    textDecorationLine: "underline",
    left: 126
  },
  cupertinoButtonSuccess2: {
    height: 44,
    width: 100,
    position: "absolute",
    left: 220,
    top: 616
  }
});

export default TelaDeResultado2;
