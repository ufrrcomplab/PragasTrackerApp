import React, { Component } from "react";
import {
  StyleSheet,
  View,
  StatusBar,
  TouchableOpacity,
  Text,
  Image
} from "react-native";
import MaterialHeader11 from "../components/MaterialHeader11";
import Icon from "react-native-vector-icons/MaterialCommunityIcons";

function TelaMenu(props) {
  return (
    <View style={styles.container}>
      <StatusBar
        animated
        barStyle="light-content"
        backgroundColor="rgba(50,104,171,1)"
      />
      <View style={styles.button2Row}>
        <TouchableOpacity
          gradientImage="Gradient_P2Y2JpI.png"
          style={styles.button2}
        >
          <View style={styles.rect2}></View>
          <MaterialHeader11
            title="Pragas Tracker"
            style={styles.materialHeader11}
          ></MaterialHeader11>
          <Text style={styles.configuracoes}>Configurações</Text>
          <Text style={styles.perfilDoUsuario}>Perfil do usuario</Text>
          <Text style={styles.perfilDoUsuario1}>Historicos de Atividades</Text>
          <Text style={styles.perfilDoUsuario2}>Iniciar classificação</Text>
          <View style={styles.rect3}></View>
          <Text style={styles.lerRecomendacoes}>Ler recomendações</Text>
          <Text style={styles.siteAgrofit}>Site AGROFIT</Text>
          <Text style={styles.contatos}>Contatos</Text>
          <View style={styles.group1}>
            <View style={styles.ufrrLogo1Row}>
              <Image
                source={require("../assets/images/Ufrr_logo.png")}
                resizeMode="contain"
                style={styles.ufrrLogo1}
              ></Image>
              <Image
                source={require("../assets/images/image_R3DO..png")}
                resizeMode="contain"
                style={styles.image1}
              ></Image>
            </View>
            <View style={styles.ufrrLogo1RowFiller}></View>
            <Image
              source={require("../assets/images/layout_set_logo1.png")}
              resizeMode="contain"
              style={styles.embrapaLogo1}
            ></Image>
          </View>
        </TouchableOpacity>
        <Icon name="home" style={styles.icon5}></Icon>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    borderWidth: 0,
    borderColor: "rgba(133,161,238,1)",
    borderBottomRightRadius: 0,
    borderBottomLeftRadius: 0,
    backgroundColor: "rgba(243,241,241,1)",
    borderStyle: "solid",
    flexDirection: "row"
  },
  button2: {
    width: 361,
    height: 740,
    borderWidth: 5,
    borderColor: "rgba(50,104,171,1)",
    borderRadius: 6,
    borderStyle: "solid",
    backgroundColor: "rgba(243,241,241,1)"
  },
  rect2: {
    flex: 0.39,
    backgroundColor: "rgba(243,241,241,1)",
    margin: 0
  },
  materialHeader11: {
    height: 56,
    width: 360,
    position: "absolute",
    left: 0,
    top: 22
  },
  configuracoes: {
    top: 93,
    position: "absolute",
    fontFamily: "alegreya-sc-700",
    color: "#121212",
    textAlign: "center",
    fontSize: 20,
    textDecorationLine: "underline",
    left: 112
  },
  perfilDoUsuario: {
    top: 133,
    position: "absolute",
    fontFamily: "alegreya-sc-700",
    color: "#121212",
    textAlign: "center",
    fontSize: 20,
    left: 102
  },
  perfilDoUsuario1: {
    top: 180,
    position: "absolute",
    fontFamily: "alegreya-sc-700",
    color: "#121212",
    textAlign: "center",
    fontSize: 20,
    left: 66
  },
  perfilDoUsuario2: {
    top: 233,
    position: "absolute",
    fontFamily: "alegreya-sc-700",
    color: "#121212",
    textAlign: "center",
    fontSize: 20,
    left: 84
  },
  rect3: {
    flex: 0.61,
    backgroundColor: "rgba(243,241,241,1)",
    margin: 0
  },
  lerRecomendacoes: {
    top: 293,
    position: "absolute",
    fontFamily: "alegreya-sc-700",
    color: "#121212",
    textAlign: "center",
    fontSize: 20,
    left: 91
  },
  siteAgrofit: {
    top: 343,
    position: "absolute",
    fontFamily: "alegreya-sc-700",
    color: "#121212",
    textAlign: "center",
    fontSize: 20,
    left: 120
  },
  contatos: {
    top: 413,
    position: "absolute",
    fontFamily: "alegreya-sc-700",
    color: "#121212",
    textAlign: "center",
    fontSize: 20,
    left: 137
  },
  group1: {
    top: 607,
    left: 17,
    width: 316,
    height: 84,
    position: "absolute",
    flexDirection: "row"
  },
  ufrrLogo1: {
    width: 99,
    height: 84
  },
  image1: {
    height: 84,
    width: 88,
    marginLeft: 20
  },
  ufrrLogo1Row: {
    height: 84,
    flexDirection: "row"
  },
  ufrrLogo1RowFiller: {
    flex: 1,
    flexDirection: "row"
  },
  embrapaLogo1: {
    width: 96,
    height: 84
  },
  icon5: {
    color: "rgba(128,128,128,1)",
    fontSize: 40,
    marginLeft: 68,
    marginTop: 505
  },
  button2Row: {
    height: 740,
    flexDirection: "row",
    flex: 1,
    marginRight: -109
  }
});

export default TelaMenu;
