import React, { Component } from "react";
import {
  StyleSheet,
  View,
  StatusBar,
  TouchableOpacity,
  Text
} from "react-native";
import MaterialHeader11 from "../components/MaterialHeader11";
import MaterialCommunityIconsIcon from "react-native-vector-icons/MaterialCommunityIcons";
import CupertinoButtonBlueTextColor1 from "../components/CupertinoButtonBlueTextColor1";
import FontAwesomeIcon from "react-native-vector-icons/FontAwesome";
import IoniconsIcon from "react-native-vector-icons/Ionicons";

function TelaCapturaFoto1(props) {
  return (
    <View style={styles.container}>
      <StatusBar
        animated
        barStyle="light-content"
        backgroundColor="rgba(50,104,171,1)"
      />
      <View style={styles.button2Row}>
        <TouchableOpacity
          gradientImage="Gradient_P2Y2JpI.png"
          style={styles.button2}
        >
          <View style={styles.rect2}></View>
          <View style={styles.rect3}></View>
          <MaterialHeader11
            title="Pragas Tracker"
            style={styles.materialHeader11}
          ></MaterialHeader11>
          <View style={styles.rect4}>
            <View style={styles.rect5}>
              <View style={styles.icon3Stack}>
                <MaterialCommunityIconsIcon
                  name="alert-outline"
                  style={styles.icon3}
                ></MaterialCommunityIconsIcon>
                <Text style={styles.condicoesDeCaptura}>
                  CONDIÇÕES DE CAPTURAS
                </Text>
              </View>
              <Text style={styles.loremIpsum}>
                Capture o inseto vivo{"\n"}Mate-lho no Alcool{"\n"}Retire o
                inseto do Alcool{"\n"} enxugue alguns minutos{"\n"}Procure um
                papel de cor magenta{"\n"}Coloque o inseto acima deste papel
                {"\n"}Procure um ambiente de forte luminosidade{"\n"}Tire uma
                foto sem sombra.{"\n"}Quando ficar bom pode mandar.
              </Text>
              <View style={styles.cupertinoButtonBlueTextColor1Row}>
                <CupertinoButtonBlueTextColor1
                  button="OK"
                  style={styles.cupertinoButtonBlueTextColor1}
                ></CupertinoButtonBlueTextColor1>
                <FontAwesomeIcon
                  name="repeat"
                  style={styles.icon4}
                ></FontAwesomeIcon>
              </View>
            </View>
          </View>
          <IoniconsIcon
            name="ios-flash-off"
            style={styles.icon2}
          ></IoniconsIcon>
          <IoniconsIcon name="md-aperture" style={styles.icon}></IoniconsIcon>
        </TouchableOpacity>
        <MaterialCommunityIconsIcon
          name="home"
          style={styles.icon5}
        ></MaterialCommunityIconsIcon>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    borderWidth: 0,
    borderColor: "rgba(133,161,238,1)",
    borderBottomRightRadius: 0,
    borderBottomLeftRadius: 0,
    backgroundColor: "rgba(243,241,241,1)",
    borderStyle: "solid",
    flexDirection: "row"
  },
  button2: {
    width: 361,
    height: 740,
    borderWidth: 5,
    borderColor: "rgba(50,104,171,1)",
    borderRadius: 6,
    borderStyle: "solid",
    backgroundColor: "rgba(243,241,241,1)"
  },
  rect2: {
    flex: 0.39,
    backgroundColor: "rgba(243,241,241,1)",
    margin: 0
  },
  rect3: {
    flex: 0.61,
    backgroundColor: "rgba(243,241,241,1)",
    margin: 0
  },
  materialHeader11: {
    height: 56,
    width: 360,
    position: "absolute",
    left: 0,
    top: 22
  },
  rect4: {
    top: 78,
    left: 0,
    width: 360,
    height: 559,
    position: "absolute",
    backgroundColor: "rgba(0,0,0,1)"
  },
  rect5: {
    width: 360,
    height: 356,
    backgroundColor: "#E6E6E6",
    marginTop: 94
  },
  icon3: {
    top: 0,
    position: "absolute",
    color: "rgba(50,104,171,1)",
    fontSize: 70,
    height: 76,
    width: 70,
    left: 85
  },
  condicoesDeCaptura: {
    top: 70,
    position: "absolute",
    fontFamily: "alegreya-sc-700",
    color: "#121212",
    fontSize: 20,
    textAlign: "center",
    textDecorationLine: "underline",
    left: 0
  },
  icon3Stack: {
    width: 240,
    height: 97,
    marginLeft: 60
  },
  loremIpsum: {
    fontFamily: "alegreya-sans-sc-regular",
    color: "#121212",
    textAlign: "center",
    fontSize: 18,
    marginTop: 6,
    marginLeft: 14
  },
  cupertinoButtonBlueTextColor1: {
    height: 44,
    width: 100,
    borderWidth: 1,
    borderColor: "rgba(50,104,171,1)"
  },
  icon4: {
    color: "rgba(50,104,171,1)",
    fontSize: 25,
    height: 25,
    width: 22,
    marginLeft: 78,
    marginTop: 6
  },
  cupertinoButtonBlueTextColor1Row: {
    height: 44,
    flexDirection: "row",
    marginTop: 6,
    marginLeft: 130,
    marginRight: 30
  },
  icon2: {
    top: 661,
    left: 60,
    position: "absolute",
    color: "rgba(0,0,0,1)",
    fontSize: 48,
    height: 52,
    width: 24
  },
  icon: {
    top: 643,
    position: "absolute",
    color: "rgba(0,0,0,1)",
    fontSize: 78,
    height: 85,
    width: 68,
    left: 146
  },
  icon5: {
    color: "rgba(128,128,128,1)",
    fontSize: 40,
    marginLeft: 68,
    marginTop: 505
  },
  button2Row: {
    height: 740,
    flexDirection: "row",
    flex: 1,
    marginRight: -109
  }
});

export default TelaCapturaFoto1;
