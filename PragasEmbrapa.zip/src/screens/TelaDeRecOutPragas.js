import React, { Component } from "react";
import {
  StyleSheet,
  View,
  StatusBar,
  TouchableOpacity,
  Text,
  ScrollView
} from "react-native";
import MaterialHeader11 from "../components/MaterialHeader11";
import FontAwesomeIcon from "react-native-vector-icons/FontAwesome";
import CupertinoButtonBlueTextColor2 from "../components/CupertinoButtonBlueTextColor2";
import CupertinoButtonSuccess3 from "../components/CupertinoButtonSuccess3";
import MaterialCommunityIconsIcon from "react-native-vector-icons/MaterialCommunityIcons";

function TelaDeRecOutPragas(props) {
  return (
    <View style={styles.container}>
      <StatusBar
        animated
        barStyle="light-content"
        backgroundColor="rgba(50,104,171,1)"
      />
      <TouchableOpacity
        gradientImage="Gradient_P2Y2JpI.png"
        style={styles.button2}
      >
        <View style={styles.rect2}></View>
        <MaterialHeader11
          title="Pragas Tracker"
          style={styles.materialHeader11}
        ></MaterialHeader11>
        <Text style={styles.outrasPragas}>Cigarrinhas-Das-Pastagens</Text>
        <View style={styles.scrollArea1}>
          <ScrollView
            horizontal={true}
            contentContainerStyle={styles.scrollArea1_contentContainerStyle}
          >
            <View style={styles.icon9Row}>
              <FontAwesomeIcon
                name="image"
                style={styles.icon9}
              ></FontAwesomeIcon>
              <FontAwesomeIcon
                name="image"
                style={styles.icon11}
              ></FontAwesomeIcon>
              <FontAwesomeIcon
                name="image"
                style={styles.icon10}
              ></FontAwesomeIcon>
              <FontAwesomeIcon
                name="image"
                style={styles.icon12}
              ></FontAwesomeIcon>
              <FontAwesomeIcon
                name="image"
                style={styles.icon13}
              ></FontAwesomeIcon>
            </View>
          </ScrollView>
        </View>
        <View style={styles.rect3}></View>
        <Text style={styles.loremIpsum2}>
          Veja aqui as RECOMENDAÇÕES de manejo e {"\n"}controle desta praga.
        </Text>
        <CupertinoButtonBlueTextColor2
          button="Ler Recomendação"
          style={styles.cupertinoButtonBlueTextColor2}
        ></CupertinoButtonBlueTextColor2>
        <View style={styles.group5}>
          <Text style={styles.produtosDeControle}>PRODUTOS DE CONTROLE</Text>
          <Text style={styles.loremIpsum}>
            Aperta no AGROFIT para acessar o portal{"\n"}Agrofit do MAPA, onde
            constam os produtos{"\n"}licenciados para o controle dessa praga.
          </Text>
          <CupertinoButtonSuccess3
            button="AGROFIT"
            style={styles.cupertinoButtonSuccess1}
          ></CupertinoButtonSuccess3>
          <Text style={styles.lheAjudou}>LHE AJUDOU ?</Text>
          <View style={styles.group4}>
            <View style={styles.group3Row}>
              <View style={styles.group3}>
                <View style={styles.icon6Stack}>
                  <MaterialCommunityIconsIcon
                    name="emoticon-cool"
                    style={styles.icon6}
                  ></MaterialCommunityIconsIcon>
                  <Text style={styles.otimo}>Ótimo</Text>
                </View>
              </View>
              <View style={styles.group2}>
                <View style={styles.icon7Stack}>
                  <MaterialCommunityIconsIcon
                    name="emoticon-neutral"
                    style={styles.icon7}
                  ></MaterialCommunityIconsIcon>
                  <Text style={styles.parcialmente}>Parcialmente</Text>
                </View>
              </View>
              <View style={styles.group}>
                <View style={styles.icon8Stack}>
                  <MaterialCommunityIconsIcon
                    name="emoticon-sad"
                    style={styles.icon8}
                  ></MaterialCommunityIconsIcon>
                  <Text style={styles.nao}>não</Text>
                </View>
              </View>
            </View>
          </View>
        </View>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    borderWidth: 0,
    borderColor: "rgba(133,161,238,1)",
    borderBottomRightRadius: 0,
    borderBottomLeftRadius: 0,
    backgroundColor: "rgba(243,241,241,1)",
    borderStyle: "solid"
  },
  button2: {
    width: 361,
    height: 740,
    borderWidth: 5,
    borderColor: "rgba(50,104,171,1)",
    borderRadius: 6,
    borderStyle: "solid",
    backgroundColor: "rgba(243,241,241,1)"
  },
  rect2: {
    flex: 0.39,
    backgroundColor: "rgba(243,241,241,1)",
    margin: 0
  },
  materialHeader11: {
    height: 56,
    width: 360,
    position: "absolute",
    left: 0,
    top: 22
  },
  outrasPragas: {
    top: 87,
    position: "absolute",
    fontFamily: "alegreya-sc-700",
    color: "#121212",
    textAlign: "center",
    fontSize: 20,
    textDecorationLine: "underline",
    left: 53
  },
  scrollArea1: {
    top: 119,
    left: 20,
    width: 326,
    height: 201,
    position: "absolute",
    backgroundColor: "rgba(230,230,230,1)"
  },
  scrollArea1_contentContainerStyle: {
    width: 952,
    height: 201,
    flexDirection: "row"
  },
  icon9: {
    color: "rgba(128,128,128,1)",
    fontSize: 150
  },
  icon11: {
    color: "rgba(128,128,128,1)",
    fontSize: 150,
    marginLeft: 29
  },
  icon10: {
    color: "rgba(128,128,128,1)",
    fontSize: 150,
    marginLeft: 30
  },
  icon12: {
    color: "rgba(128,128,128,1)",
    fontSize: 150,
    marginLeft: 34
  },
  icon13: {
    color: "rgba(128,128,128,1)",
    fontSize: 150,
    marginLeft: 31
  },
  icon9Row: {
    height: 150,
    flexDirection: "row",
    flex: 1,
    marginRight: -626,
    marginLeft: 23,
    marginTop: 26
  },
  rect3: {
    flex: 0.61,
    backgroundColor: "rgba(243,241,241,1)",
    margin: 0
  },
  loremIpsum2: {
    top: 327,
    position: "absolute",
    fontFamily: "roboto-regular",
    color: "#121212",
    textAlign: "center",
    left: 40
  },
  cupertinoButtonBlueTextColor2: {
    height: 34,
    width: 217,
    position: "absolute",
    top: 372,
    borderWidth: 1,
    borderColor: "rgba(50,104,171,1)",
    left: 71
  },
  group5: {
    top: 422,
    left: 31,
    width: 299,
    height: 280,
    position: "absolute"
  },
  produtosDeControle: {
    fontFamily: "alegreya-sc-700",
    color: "#121212",
    textAlign: "center",
    fontSize: 20,
    textDecorationLine: "underline",
    marginLeft: 34
  },
  loremIpsum: {
    fontFamily: "alegreya-sans-sc-regular",
    color: "#121212",
    fontSize: 16,
    textAlign: "center",
    marginTop: 10
  },
  cupertinoButtonSuccess1: {
    height: 32,
    width: 100,
    marginTop: 16,
    marginLeft: 100
  },
  lheAjudou: {
    fontFamily: "alegreya-sc-regular",
    color: "#121212",
    textAlign: "center",
    fontSize: 17,
    marginTop: 17,
    marginLeft: 97
  },
  group4: {
    width: 260,
    height: 81,
    flexDirection: "row",
    marginTop: 17,
    marginLeft: 19
  },
  group3: {
    width: 60,
    height: 81
  },
  icon6: {
    top: 0,
    left: 0,
    position: "absolute",
    color: "rgba(0,230,118,1)",
    fontSize: 60
  },
  otimo: {
    top: 62,
    left: 11,
    position: "absolute",
    fontFamily: "alegreya-sc-700",
    color: "rgba(0,230,118,1)",
    textAlign: "center"
  },
  icon6Stack: {
    width: 60,
    height: 81
  },
  group2: {
    width: 88,
    height: 81,
    marginLeft: 27
  },
  icon7: {
    top: 0,
    position: "absolute",
    color: "rgba(255,215,40,1)",
    fontSize: 60,
    left: 13
  },
  parcialmente: {
    top: 62,
    position: "absolute",
    fontFamily: "alegreya-sc-700",
    color: "rgba(255,215,40,1)",
    textAlign: "center",
    left: 0
  },
  icon7Stack: {
    width: 88,
    height: 81
  },
  group: {
    width: 60,
    height: 81,
    marginLeft: 25
  },
  icon8: {
    top: 0,
    left: 0,
    position: "absolute",
    color: "rgba(217,48,37,1)",
    fontSize: 60
  },
  nao: {
    top: 62,
    left: 19,
    position: "absolute",
    fontFamily: "alegreya-sc-700",
    color: "rgba(217,48,37,1)",
    textAlign: "center"
  },
  icon8Stack: {
    width: 60,
    height: 81
  },
  group3Row: {
    height: 81,
    flexDirection: "row",
    flex: 1
  }
});

export default TelaDeRecOutPragas;
