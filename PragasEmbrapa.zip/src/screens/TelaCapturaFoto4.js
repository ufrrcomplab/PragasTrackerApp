import React, { Component } from "react";
import { StyleSheet, View, StatusBar, TouchableOpacity } from "react-native";
import MaterialHeader11 from "../components/MaterialHeader11";
import IoniconsIcon from "react-native-vector-icons/Ionicons";
import MaterialCommunityIconsIcon from "react-native-vector-icons/MaterialCommunityIcons";

function TelaCapturaFoto4(props) {
  return (
    <View style={styles.container}>
      <StatusBar
        animated
        barStyle="light-content"
        backgroundColor="rgba(50,104,171,1)"
      />
      <View style={styles.button2Row}>
        <TouchableOpacity
          gradientImage="Gradient_P2Y2JpI.png"
          style={styles.button2}
        >
          <View style={styles.rect2}></View>
          <View style={styles.rect3}></View>
          <MaterialHeader11
            title="Pragas Tracker"
            style={styles.materialHeader11}
          ></MaterialHeader11>
          <View style={styles.rect4}></View>
          <IoniconsIcon name="ios-refresh" style={styles.icon2}></IoniconsIcon>
          <IoniconsIcon name="md-send" style={styles.icon}></IoniconsIcon>
        </TouchableOpacity>
        <MaterialCommunityIconsIcon
          name="home"
          style={styles.icon5}
        ></MaterialCommunityIconsIcon>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    borderWidth: 0,
    borderColor: "rgba(133,161,238,1)",
    borderBottomRightRadius: 0,
    borderBottomLeftRadius: 0,
    backgroundColor: "rgba(243,241,241,1)",
    borderStyle: "solid",
    flexDirection: "row"
  },
  button2: {
    width: 361,
    height: 740,
    borderWidth: 5,
    borderColor: "rgba(50,104,171,1)",
    borderRadius: 6,
    borderStyle: "solid",
    backgroundColor: "rgba(243,241,241,1)"
  },
  rect2: {
    flex: 0.39,
    backgroundColor: "rgba(243,241,241,1)",
    margin: 0
  },
  rect3: {
    flex: 0.61,
    backgroundColor: "rgba(243,241,241,1)",
    margin: 0
  },
  materialHeader11: {
    height: 56,
    width: 360,
    position: "absolute",
    left: 0,
    top: 22
  },
  rect4: {
    top: 78,
    left: 0,
    width: 360,
    height: 559,
    position: "absolute",
    backgroundColor: "rgba(0,0,0,1)"
  },
  icon2: {
    top: 649,
    left: 49,
    position: "absolute",
    color: "rgba(217,48,37,1)",
    fontSize: 60,
    height: 66,
    width: 45
  },
  icon: {
    top: 648,
    position: "absolute",
    color: "rgba(0,230,118,1)",
    fontSize: 60,
    left: 258,
    right: 54,
    height: 66,
    width: 49
  },
  icon5: {
    color: "rgba(128,128,128,1)",
    fontSize: 40,
    marginLeft: 68,
    marginTop: 505
  },
  button2Row: {
    height: 740,
    flexDirection: "row",
    flex: 1,
    marginRight: -109
  }
});

export default TelaCapturaFoto4;
