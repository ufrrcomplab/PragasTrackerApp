import React, { Component } from "react";
import {
  StyleSheet,
  View,
  StatusBar,
  TouchableOpacity,
  Text,
  ScrollView
} from "react-native";
import MaterialHeader11 from "../components/MaterialHeader11";
import FontAwesomeIcon from "react-native-vector-icons/FontAwesome";
import MaterialCommunityIconsIcon from "react-native-vector-icons/MaterialCommunityIcons";

function TelaDeResultado1(props) {
  return (
    <View style={styles.container}>
      <StatusBar
        animated
        barStyle="light-content"
        backgroundColor="rgba(50,104,171,1)"
      />
      <TouchableOpacity
        gradientImage="Gradient_P2Y2JpI.png"
        style={styles.button2}
      >
        <View style={styles.rect2}></View>
        <MaterialHeader11
          title="Pragas Tracker"
          style={styles.materialHeader11}
        ></MaterialHeader11>
        <View style={styles.group2}>
          <Text style={styles.resultado}>RESULTADO</Text>
          <View style={styles.scrollArea1}>
            <ScrollView
              horizontal={true}
              contentContainerStyle={styles.scrollArea1_contentContainerStyle}
            >
              <View style={styles.icon9Row}>
                <FontAwesomeIcon
                  name="image"
                  style={styles.icon9}
                ></FontAwesomeIcon>
                <FontAwesomeIcon
                  name="image"
                  style={styles.icon11}
                ></FontAwesomeIcon>
                <FontAwesomeIcon
                  name="image"
                  style={styles.icon10}
                ></FontAwesomeIcon>
                <FontAwesomeIcon
                  name="image"
                  style={styles.icon12}
                ></FontAwesomeIcon>
                <FontAwesomeIcon
                  name="image"
                  style={styles.icon13}
                ></FontAwesomeIcon>
              </View>
            </ScrollView>
          </View>
          <Text style={styles.os}>
            Os resultados mostram que há{"\n"} uma probabilidade 70 % que sua
            foto{"\n"} seja dos insectos acima.
          </Text>
          <Text style={styles.avaliacao}>AVALIAÇÃO</Text>
          <Text style={styles.loremIpsum}>
            Escolha a figura que mais representa{"\n"} sua confiança que o
            inseto das fotos{"\n"} acima são da mesma espécie{"\n"}que o da sua
            foto ?
          </Text>
          <View style={styles.group}>
            <View style={styles.icon6Row}>
              <MaterialCommunityIconsIcon
                name="emoticon-cool"
                style={styles.icon6}
              ></MaterialCommunityIconsIcon>
              <MaterialCommunityIconsIcon
                name="emoticon-neutral"
                style={styles.icon7}
              ></MaterialCommunityIconsIcon>
              <MaterialCommunityIconsIcon
                name="emoticon-sad"
                style={styles.icon8}
              ></MaterialCommunityIconsIcon>
            </View>
            <View style={styles.tenhoCertezaRow}>
              <Text style={styles.tenhoCerteza}>Tenho {"\n"}Certeza</Text>
              <Text style={styles.estouDuvidando}>Estou{"\n"}Dúvidando</Text>
              <Text style={styles.achoQueNaoE}>Acho{"\n"}Que não é</Text>
            </View>
          </View>
        </View>
        <View style={styles.rect3}></View>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    borderWidth: 0,
    borderColor: "rgba(133,161,238,1)",
    borderBottomRightRadius: 0,
    borderBottomLeftRadius: 0,
    backgroundColor: "rgba(243,241,241,1)",
    borderStyle: "solid"
  },
  button2: {
    width: 361,
    height: 740,
    borderWidth: 5,
    borderColor: "rgba(50,104,171,1)",
    borderRadius: 6,
    borderStyle: "solid",
    backgroundColor: "rgba(243,241,241,1)",
    marginLeft: -1
  },
  rect2: {
    flex: 0.39,
    backgroundColor: "rgba(243,241,241,1)",
    margin: 0
  },
  materialHeader11: {
    height: 56,
    width: 360,
    position: "absolute",
    left: 1,
    top: 22
  },
  group2: {
    top: 85,
    left: 18,
    width: 326,
    height: 584,
    position: "absolute"
  },
  resultado: {
    fontFamily: "alegreya-sc-700",
    color: "#121212",
    textAlign: "center",
    fontSize: 20,
    textDecorationLine: "underline",
    marginLeft: 108
  },
  scrollArea1: {
    width: 326,
    height: 201,
    backgroundColor: "rgba(230,230,230,1)",
    marginTop: 8
  },
  scrollArea1_contentContainerStyle: {
    width: 952,
    height: 201,
    flexDirection: "row"
  },
  icon9: {
    color: "rgba(128,128,128,1)",
    fontSize: 150
  },
  icon11: {
    color: "rgba(128,128,128,1)",
    fontSize: 150,
    marginLeft: 29
  },
  icon10: {
    color: "rgba(128,128,128,1)",
    fontSize: 150,
    marginLeft: 30
  },
  icon12: {
    color: "rgba(128,128,128,1)",
    fontSize: 150,
    marginLeft: 34
  },
  icon13: {
    color: "rgba(128,128,128,1)",
    fontSize: 150,
    marginLeft: 31
  },
  icon9Row: {
    height: 150,
    flexDirection: "row",
    flex: 1,
    marginRight: -626,
    marginLeft: 23,
    marginTop: 26
  },
  os: {
    fontFamily: "alegreya-sans-sc-700",
    color: "#121212",
    textAlign: "center",
    fontSize: 20,
    marginTop: 6,
    marginLeft: 4
  },
  avaliacao: {
    fontFamily: "alegreya-sc-700",
    color: "#121212",
    textAlign: "center",
    fontSize: 20,
    textDecorationLine: "underline",
    marginTop: 12,
    marginLeft: 112
  },
  loremIpsum: {
    fontFamily: "alegreya-sans-sc-regular",
    color: "#121212",
    fontSize: 19,
    textAlign: "center",
    marginTop: 14,
    marginLeft: 15
  },
  group: {
    width: 261,
    height: 119,
    marginTop: 6,
    marginLeft: 34
  },
  icon6: {
    color: "rgba(0,230,118,1)",
    fontSize: 60,
    marginTop: 1
  },
  icon7: {
    color: "rgba(255,215,40,1)",
    fontSize: 60,
    marginLeft: 39
  },
  icon8: {
    color: "rgba(217,48,37,1)",
    fontSize: 60,
    marginLeft: 40,
    marginTop: 1
  },
  icon6Row: {
    height: 67,
    flexDirection: "row",
    marginRight: 2
  },
  tenhoCerteza: {
    fontFamily: "alegreya-sc-700",
    color: "rgba(0,230,118,1)",
    textAlign: "center"
  },
  estouDuvidando: {
    fontFamily: "alegreya-sc-700",
    color: "rgba(255,215,40,1)",
    textAlign: "center",
    marginLeft: 39
  },
  achoQueNaoE: {
    fontFamily: "alegreya-sc-700",
    color: "rgba(217,48,37,1)",
    textAlign: "center",
    marginLeft: 36
  },
  tenhoCertezaRow: {
    height: 38,
    flexDirection: "row",
    marginTop: 14,
    marginLeft: 4
  },
  rect3: {
    flex: 0.61,
    backgroundColor: "rgba(243,241,241,1)",
    margin: 0
  }
});

export default TelaDeResultado1;
