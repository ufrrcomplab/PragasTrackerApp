import React, { Component } from "react";
import {
  StyleSheet,
  View,
  StatusBar,
  TouchableOpacity,
  Text,
  ScrollView
} from "react-native";
import MaterialHeader11 from "../components/MaterialHeader11";
import MaterialCommunityIconsIcon from "react-native-vector-icons/MaterialCommunityIcons";

function TelaDeResultado1(props) {
  return (
    <View style={styles.container}>
      <StatusBar
        animated
        barStyle="light-content"
        backgroundColor="rgba(50,104,171,1)"
      />
      <TouchableOpacity
        gradientImage="Gradient_P2Y2JpI.png"
        style={styles.button2}
      >
        <View style={styles.rect2}></View>
        <View style={styles.rect3}></View>
        <MaterialHeader11
          title="Pragas Tracker"
          style={styles.materialHeader11}
        ></MaterialHeader11>
        <Text style={styles.os}>
          Os resultados mostram que há{"\n"} uma probabilidade 70 % que sua foto
          {"\n"} seja dos insectos acima.
        </Text>
        <View style={styles.scrollArea}>
          <ScrollView
            horizontal={true}
            contentContainerStyle={styles.scrollArea_contentContainerStyle}
          ></ScrollView>
        </View>
        <Text style={styles.loremIpsum}>
          Escolha a figura que mais representa{"\n"} sua confiança que o inseto
          das fotos{"\n"} acima são da mesma espécie{"\n"}que o da sua foto ?
        </Text>
        <MaterialCommunityIconsIcon
          name="emoticon-cool"
          style={styles.icon6}
        ></MaterialCommunityIconsIcon>
        <Text style={styles.tenhoCerteza}>Tenho {"\n"}Certeza</Text>
        <Text style={styles.resultado}>RESULTADO</Text>
        <Text style={styles.avaliacao}>AVALIAÇÃO</Text>
        <Text style={styles.estouDuvidando}>Estou{"\n"}Dúvidando</Text>
        <MaterialCommunityIconsIcon
          name="emoticon-neutral"
          style={styles.icon7}
        ></MaterialCommunityIconsIcon>
        <MaterialCommunityIconsIcon
          name="emoticon-sad"
          style={styles.icon8}
        ></MaterialCommunityIconsIcon>
        <Text style={styles.achoQueNaoE}>Acho{"\n"}Que não é</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    borderWidth: 0,
    borderColor: "rgba(133,161,238,1)",
    borderBottomRightRadius: 0,
    borderBottomLeftRadius: 0,
    backgroundColor: "rgba(243,241,241,1)",
    borderStyle: "solid"
  },
  button2: {
    width: 361,
    height: 740,
    borderWidth: 5,
    borderColor: "rgba(50,104,171,1)",
    borderRadius: 6,
    borderStyle: "solid",
    backgroundColor: "rgba(243,241,241,1)",
    marginLeft: -1
  },
  rect2: {
    flex: 0.39,
    backgroundColor: "rgba(243,241,241,1)",
    margin: 0
  },
  rect3: {
    flex: 0.61,
    backgroundColor: "rgba(243,241,241,1)",
    margin: 0
  },
  materialHeader11: {
    height: 56,
    width: 360,
    position: "absolute",
    left: 1,
    top: 22
  },
  os: {
    top: 327,
    position: "absolute",
    fontFamily: "alegreya-sans-sc-700",
    color: "#121212",
    textAlign: "center",
    fontSize: 20,
    left: 21
  },
  scrollArea: {
    top: 147,
    width: 301,
    height: 158,
    position: "absolute",
    backgroundColor: "#E6E6E6",
    left: 30
  },
  scrollArea_contentContainerStyle: {
    width: 301,
    height: 158
  },
  loremIpsum: {
    top: 452,
    position: "absolute",
    fontFamily: "alegreya-sans-sc-regular",
    color: "#121212",
    fontSize: 19,
    textAlign: "center",
    left: 33
  },
  icon6: {
    top: 551,
    left: 52,
    position: "absolute",
    color: "rgba(0,230,118,1)",
    fontSize: 60,
    height: 66,
    width: 60
  },
  tenhoCerteza: {
    top: 632,
    left: 56,
    position: "absolute",
    fontFamily: "alegreya-sc-700",
    color: "rgba(0,230,118,1)",
    textAlign: "center"
  },
  resultado: {
    top: 101,
    position: "absolute",
    fontFamily: "alegreya-sc-700",
    color: "#121212",
    textAlign: "center",
    fontSize: 20,
    textDecorationLine: "underline",
    left: 127
  },
  avaliacao: {
    top: 411,
    position: "absolute",
    fontFamily: "alegreya-sc-700",
    color: "#121212",
    textAlign: "center",
    fontSize: 20,
    textDecorationLine: "underline",
    left: 129
  },
  estouDuvidando: {
    top: 632,
    left: 147,
    position: "absolute",
    fontFamily: "alegreya-sc-700",
    color: "rgba(255,215,40,1)",
    textAlign: "center"
  },
  icon7: {
    top: 551,
    position: "absolute",
    color: "rgba(255,215,40,1)",
    fontSize: 60,
    height: 66,
    width: 60,
    left: 151
  },
  icon8: {
    top: 551,
    left: 251,
    position: "absolute",
    color: "rgba(217,48,37,1)",
    fontSize: 60,
    height: 66,
    width: 60
  },
  achoQueNaoE: {
    top: 632,
    left: 253,
    position: "absolute",
    fontFamily: "alegreya-sc-700",
    color: "rgba(217,48,37,1)",
    textAlign: "center"
  }
});

export default TelaDeResultado1;
