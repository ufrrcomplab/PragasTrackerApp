import React, { Component } from "react";
import { StyleSheet, View, StatusBar, Text } from "react-native";
import MaterialHeader1 from "../components/MaterialHeader1";
import MaterialUnderlineTextbox from "../components/MaterialUnderlineTextbox";
import MaterialUnderlineTextbox1 from "../components/MaterialUnderlineTextbox1";
import MaterialUnderlineTextbox2 from "../components/MaterialUnderlineTextbox2";
import MaterialUnderlineTextbox4 from "../components/MaterialUnderlineTextbox4";
import MaterialUnderlineTextbox3 from "../components/MaterialUnderlineTextbox3";
import CupertinoButtonSuccess1 from "../components/CupertinoButtonSuccess1";

function TelaConfigPerfils(props) {
  return (
    <View style={styles.container}>
      <StatusBar
        animated
        barStyle="light-content"
        backgroundColor="rgba(50,104,171,1)"
      />
      <View gradientImage="Gradient_P2Y2JpI.png" style={styles.rect}>
        <View style={styles.materialHeader1Column}>
          <MaterialHeader1
            leftIconButton="Login"
            title="Pragas Tracker"
            style={styles.materialHeader1}
          ></MaterialHeader1>
          <Text style={styles.configuracoes1}>CONFIGURAÇÕES</Text>
          <MaterialUnderlineTextbox
            inputStyle="Placeholder"
            inputStyle="              Nome"
            style={styles.materialUnderlineTextbox1}
          ></MaterialUnderlineTextbox>
          <MaterialUnderlineTextbox1
            inputStyle="Placeholder"
            inputStyle="              Email"
            style={styles.materialUnderlineTextbox2}
          ></MaterialUnderlineTextbox1>
          <MaterialUnderlineTextbox2
            inputStyle="Placeholder"
            inputStyle="             CPF"
            style={styles.materialUnderlineTextbox3}
          ></MaterialUnderlineTextbox2>
          <MaterialUnderlineTextbox4
            inputStyle="Placeholder"
            inputStyle="             Estado"
            style={styles.materialUnderlineTextbox5}
          ></MaterialUnderlineTextbox4>
          <MaterialUnderlineTextbox3
            inputStyle="Placeholder"
            inputStyle="             Município da fazenda"
            style={styles.materialUnderlineTextbox4}
          ></MaterialUnderlineTextbox3>
          <MaterialUnderlineTextbox4
            inputStyle="Placeholder"
            inputStyle="             Perfil do Usúario"
            style={styles.materialUnderlineTextbox7}
          ></MaterialUnderlineTextbox4>
          <MaterialUnderlineTextbox4
            inputStyle="Placeholder"
            inputStyle="             Instituição / Empresa"
            style={styles.materialUnderlineTextbox6}
          ></MaterialUnderlineTextbox4>
          <MaterialUnderlineTextbox4
            inputStyle="Placeholder"
            inputStyle="             Numero de telephone"
            style={styles.materialUnderlineTextbox8}
          ></MaterialUnderlineTextbox4>
          <CupertinoButtonSuccess1
            button="Salvar"
            style={styles.cupertinoButtonSuccess1}
          ></CupertinoButtonSuccess1>
        </View>
        <Text style={styles.emColaboracao1}>Em colaboração</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    borderWidth: 0,
    borderColor: "rgba(133,161,238,1)",
    borderBottomRightRadius: 0,
    borderBottomLeftRadius: 0,
    backgroundColor: "rgba(243,241,241,1)",
    borderStyle: "solid"
  },
  rect: {
    width: 361,
    height: 740,
    borderWidth: 5,
    borderColor: "rgba(50,104,171,1)",
    borderRadius: 6,
    borderStyle: "solid",
    backgroundColor: "rgba(243,241,241,1)"
  },
  materialHeader1: {
    height: 62,
    width: 360,
    borderRadius: 10
  },
  configuracoes1: {
    fontFamily: "alegreya-sans-sc-800",
    color: "rgba(50,104,171,1)",
    fontSize: 25,
    lineHeight: 30,
    marginTop: 21,
    marginLeft: 89
  },
  materialUnderlineTextbox1: {
    height: 46,
    width: 272,
    backgroundColor: "rgba(185,235,197,1)",
    borderRadius: 5,
    marginTop: 19,
    marginLeft: 44
  },
  materialUnderlineTextbox2: {
    height: 46,
    width: 272,
    backgroundColor: "rgba(185,235,197,1)",
    borderRadius: 5,
    marginTop: 13,
    marginLeft: 44
  },
  materialUnderlineTextbox3: {
    height: 46,
    width: 272,
    backgroundColor: "rgba(185,235,197,1)",
    borderRadius: 5,
    marginTop: 16,
    marginLeft: 44
  },
  materialUnderlineTextbox5: {
    height: 46,
    width: 271,
    backgroundColor: "rgba(185,235,197,1)",
    borderRadius: 5,
    marginTop: 16,
    marginLeft: 45
  },
  materialUnderlineTextbox4: {
    height: 46,
    width: 271,
    backgroundColor: "rgba(185,235,197,1)",
    borderRadius: 5,
    marginTop: 16,
    marginLeft: 45
  },
  materialUnderlineTextbox7: {
    height: 46,
    width: 271,
    backgroundColor: "rgba(185,235,197,1)",
    borderRadius: 5,
    marginTop: 16,
    marginLeft: 45
  },
  materialUnderlineTextbox6: {
    height: 46,
    width: 271,
    backgroundColor: "rgba(185,235,197,1)",
    borderRadius: 5,
    marginTop: 15,
    marginLeft: 45
  },
  materialUnderlineTextbox8: {
    height: 46,
    width: 271,
    backgroundColor: "rgba(185,235,197,1)",
    borderRadius: 5,
    marginTop: 16,
    marginLeft: 45
  },
  cupertinoButtonSuccess1: {
    height: 44,
    width: 131,
    backgroundColor: "rgba(255,204,0,1)",
    marginTop: 25,
    marginLeft: 114
  },
  materialHeader1Column: {
    width: 360,
    marginTop: 20
  },
  emColaboracao1: {
    fontFamily: "alegreya-sc-500",
    color: "rgba(255,255,255,1)",
    fontSize: 20,
    textAlign: "center",
    lineHeight: 20,
    opacity: 0.5,
    flex: 1,
    marginBottom: 174,
    marginTop: -131,
    marginLeft: 106
  }
});

export default TelaConfigPerfils;
