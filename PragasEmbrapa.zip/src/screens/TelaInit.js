import React, { Component } from "react";
import { StyleSheet, View, StatusBar, Text, Image } from "react-native";

function TelaInit(props) {
  return (
    <View style={styles.container}>
      <StatusBar
        animated
        barStyle="light-content"
        backgroundColor="rgba(50,104,171,1)"
      />
      <View gradientImage="Gradient_P2Y2JpI.png" style={styles.rect}>
        <View style={styles.emColaboracao1Stack}>
          <Text style={styles.emColaboracao1}>Em colaboração</Text>
          <View style={styles.group}>
            <Image
              source={require("../assets/images/8c4f7617-8963-4c00-b5ae-44c1e2bfe4df_200x200.png")}
              resizeMode="contain"
              style={styles.appLogo}
            ></Image>
            <View style={styles.ufrrLogoRow}>
              <Image
                source={require("../assets/images/Ufrr_logo.png")}
                resizeMode="contain"
                style={styles.ufrrLogo}
              ></Image>
              <Image
                source={require("../assets/images/layout_set_logo1.png")}
                resizeMode="contain"
                style={styles.embrapaLogo}
              ></Image>
            </View>
            <Image
              source={require("../assets/images/image_R3DO..png")}
              resizeMode="contain"
              style={styles.image}
            ></Image>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    borderWidth: 0,
    borderColor: "rgba(133,161,238,1)",
    borderBottomRightRadius: 0,
    borderBottomLeftRadius: 0,
    backgroundColor: "rgba(243,241,241,1)",
    borderStyle: "solid"
  },
  rect: {
    width: 361,
    height: 740,
    borderWidth: 5,
    borderColor: "rgba(50,104,171,1)",
    borderRadius: 6,
    borderStyle: "solid",
    backgroundColor: "rgba(243,241,241,1)"
  },
  emColaboracao1: {
    top: 435,
    position: "absolute",
    fontFamily: "alegreya-sc-500",
    color: "rgba(255,255,255,1)",
    fontSize: 20,
    textAlign: "center",
    lineHeight: 20,
    bottom: 121,
    opacity: 0.5,
    left: 98
  },
  group: {
    top: 0,
    left: 0,
    width: 336,
    height: 556,
    position: "absolute"
  },
  appLogo: {
    width: 201,
    height: 220,
    borderRadius: 100,
    marginLeft: 74
  },
  ufrrLogo: {
    width: 103,
    height: 92
  },
  embrapaLogo: {
    width: 100,
    height: 92,
    marginLeft: 133
  },
  ufrrLogoRow: {
    height: 92,
    flexDirection: "row",
    marginTop: 79
  },
  image: {
    height: 99,
    width: 86,
    marginTop: 66,
    marginLeft: 131
  },
  emColaboracao1Stack: {
    width: 336,
    flex: 1,
    marginBottom: 53,
    marginTop: 131,
    marginLeft: 8
  }
});

export default TelaInit;
