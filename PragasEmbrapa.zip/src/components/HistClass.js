import React, { Component } from "react";
import { StyleSheet, View, Image, Text } from "react-native";
import Data from "./Data";
import Hora from "./Hora";
import Icon from "react-native-vector-icons/MaterialCommunityIcons";

function HistClass(props) {
  return (
    <View style={[styles.container, props.style]}>
      <View style={styles.imageRow}>
        <Image
          source={require("../assets/images/png-transparent-butterfly-blue-butterfly-blue-brush-footed-butterfly-insects1.png")}
          resizeMode="stretch"
          style={styles.image}
        ></Image>
        <View style={styles.dataRowColumn}>
          <View style={styles.dataRow}>
            <Data style={styles.data}></Data>
            <Hora loremIpsum="15 :39" style={styles.hora}></Hora>
          </View>
          <Text style={styles.blissusPulch}>Blissus Pulch</Text>
        </View>
        <View style={styles.iconColumn}>
          <Icon name="emoticon-cool" style={styles.icon}></Icon>
          <Text style={styles.loremIpsum}>67 %</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "rgba(185,235,197,1)",
    borderWidth: 1,
    borderColor: "#000000",
    borderRadius: 10
  },
  image: {
    width: 62,
    height: 58,
    borderWidth: 1,
    borderColor: "#000000",
    borderRadius: 42,
    marginTop: 5
  },
  data: {
    height: 24,
    width: 94,
    borderRadius: 3
  },
  hora: {
    width: 48,
    height: 14,
    borderRadius: 3,
    marginLeft: 11,
    marginTop: 5
  },
  dataRow: {
    height: 24,
    flexDirection: "row",
    marginRight: 10
  },
  blissusPulch: {
    fontFamily: "roboto-regular",
    color: "#121212",
    fontSize: 25,
    marginTop: 2,
    marginLeft: 9
  },
  dataRowColumn: {
    width: 163,
    marginLeft: 9,
    marginTop: 4,
    marginBottom: 4
  },
  icon: {
    color: "rgba(255,200,61,1)",
    fontSize: 27,
    marginLeft: 14
  },
  loremIpsum: {
    fontFamily: "roboto-regular",
    color: "#121212",
    fontSize: 25,
    marginTop: 1
  },
  iconColumn: {
    width: 58,
    marginLeft: 2,
    marginBottom: 4
  },
  imageRow: {
    height: 63,
    flexDirection: "row",
    marginTop: 8,
    marginLeft: 13,
    marginRight: 11
  }
});

export default HistClass;
