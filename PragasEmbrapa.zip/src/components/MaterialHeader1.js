import React, { Component } from "react";
import { StyleSheet, View, TouchableOpacity, Text } from "react-native";
import Icon from "react-native-vector-icons/MaterialCommunityIcons";

function MaterialHeader1(props) {
  return (
    <View style={[styles.container, props.style]}>
      <TouchableOpacity /* Conditional navigation not supported at the moment */
        style={styles.leftIconButton}
      >
        <Icon name="menu" style={styles.leftIcon}></Icon>
      </TouchableOpacity>
      <View style={styles.textWrapper}>
        <Text numberOfLines={1} style={styles.title}>
          {props.title || "Title"}
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "rgba(50,104,171,1)",
    flexDirection: "row",
    alignItems: "center",
    padding: 4,
    justifyContent: "space-between",
    shadowColor: "#111",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.2,
    shadowRadius: 1.2,
    elevation: 3
  },
  leftIconButton: {
    padding: 11,
    marginTop: 5
  },
  leftIcon: {
    backgroundColor: "transparent",
    color: "rgba(243,241,241,1)",
    fontSize: 24
  },
  textWrapper: {
    height: 18,
    marginLeft: 166,
    alignSelf: "center"
  },
  title: {
    fontFamily: "alegreya-sans-sc-500",
    fontSize: 25,
    color: "rgba(243,241,241,1)",
    backgroundColor: "transparent",
    lineHeight: 18,
    textAlign: "center",
    alignSelf: "flex-start"
  }
});

export default MaterialHeader1;
