import React, { Component } from "react";
import { StyleSheet, View, TextInput } from "react-native";

function ModalidadeCultura(props) {
  return (
    <View style={[styles.container, props.style]}>
      <TextInput
        placeholder={props.textInput || "MODALIDADE"}
        selectionColor="rgba(0,0,0,1)"
        placeholderTextColor="rgba(0,0,0,1)"
        style={styles.textInput}
      ></TextInput>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "rgba(185,235,197,1)",
    borderWidth: 4,
    borderColor: "rgba(243,241,241,1)",
    borderRadius: 12,
    justifyContent: "center"
  },
  textInput: {
    fontFamily: "alegreya-sans-sc-regular",
    color: "rgba(0,0,0,1)",
    fontSize: 45,
    textAlign: "center",
    width: 281,
    height: 54,
    opacity: 0.7,
    alignSelf: "center"
  }
});

export default ModalidadeCultura;
