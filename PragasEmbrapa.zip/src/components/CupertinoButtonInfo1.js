import React, { Component } from "react";
import { StyleSheet, TouchableOpacity, Text } from "react-native";
import { Center } from "@builderx/utils";
import Icon from "react-native-vector-icons/Entypo";

function CupertinoButtonInfo1(props) {
  return (
    <TouchableOpacity style={[styles.container, props.style]}>
      <Text style={styles.caption}>{props.caption || ""}</Text>
      <Center vertical>
        <Icon name="facebook-with-circle" style={styles.icon}></Icon>
      </Center>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    paddingLeft: 16,
    paddingRight: 16,
    borderWidth: 4,
    borderColor: "rgba(4,111,229,1)",
    borderStyle: "solid",
    borderRadius: 9
  },
  caption: {
    color: "#fff",
    fontSize: 20,
    fontFamily: "aldrich-regular",
    textAlign: "center"
  },
  icon: {
    position: "absolute",
    color: "rgba(4,111,229,1)",
    fontSize: 40,
    left: 26
  }
});

export default CupertinoButtonInfo1;
