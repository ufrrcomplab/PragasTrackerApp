import React, { Component } from "react";
import { StyleSheet, View } from "react-native";
import EntypoIcon from "react-native-vector-icons/Entypo";

function AvaliaO(props) {
  return (
    <View style={[styles.container, props.style]}>
      <EntypoIcon name="star-outlined" style={styles.icon2}></EntypoIcon>
      <View style={styles.icon6Row}>
        <EntypoIcon name="star-outlined" style={styles.icon6}></EntypoIcon>
        <EntypoIcon name="star-outlined" style={styles.icon4}></EntypoIcon>
        <EntypoIcon name="star-outlined" style={styles.icon1}></EntypoIcon>
        <EntypoIcon name="star-outlined" style={styles.icon3}></EntypoIcon>
        <EntypoIcon name="star-outlined" style={styles.icon5}></EntypoIcon>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "rgba(230,230, 230,0)",
    flexDirection: "row"
  },
  icon2: {
    color: "rgba(128,128,128,1)",
    fontSize: 21,
    marginLeft: 264,
    marginTop: 93
  },
  icon6: {
    color: "rgba(0,0,0,1)",
    fontSize: 10
  },
  icon4: {
    color: "rgba(0,0,0,1)",
    fontSize: 10,
    marginLeft: 1
  },
  icon1: {
    color: "rgba(0,0,0,1)",
    fontSize: 10
  },
  icon3: {
    color: "rgba(0,0,0,1)",
    fontSize: 10,
    marginLeft: 2
  },
  icon5: {
    color: "rgba(0,0,0,1)",
    fontSize: 10,
    marginLeft: 1
  },
  icon6Row: {
    height: 11,
    flexDirection: "row",
    flex: 1,
    marginRight: 4,
    marginLeft: -280,
    marginTop: 2
  }
});

export default AvaliaO;
