import React, { Component } from "react";
import { StyleSheet, TouchableOpacity, Text } from "react-native";

function CupertinoButtonSuccess(props) {
  return (
    <TouchableOpacity style={[styles.container, props.style]}>
      <Text style={styles.button}>{props.button || "Button"}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "rgba(255,204,0,1)",
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    borderRadius: 10,
    paddingLeft: 16,
    paddingRight: 16,
    borderWidth: 2,
    borderColor: "rgba(0,0,0,1)",
    opacity: 0.8
  },
  button: {
    color: "rgba(0,0,0,1)",
    fontSize: 17,
    fontFamily: "aldrich-regular",
    opacity: 0.86
  }
});

export default CupertinoButtonSuccess;
