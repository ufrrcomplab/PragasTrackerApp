import React, { Component } from "react";
import { StyleSheet, TouchableOpacity, Text } from "react-native";
import { Center } from "@builderx/utils";
import Icon from "react-native-vector-icons/MaterialCommunityIcons";

function CupertinoButtonWarning(props) {
  return (
    <TouchableOpacity style={[styles.container, props.style]}>
      <Text style={styles.button}>{props.button || ""}</Text>
      <Center vertical>
        <Icon name="gmail" style={styles.icon1}></Icon>
      </Center>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    borderRadius: 9,
    paddingLeft: 16,
    paddingRight: 16,
    borderWidth: 4,
    borderColor: "rgba(217,48,37,1)"
  },
  button: {
    color: "rgba(243,241,241,1)",
    fontSize: 20,
    fontFamily: "aldrich-regular",
    textAlign: "center"
  },
  icon1: {
    position: "absolute",
    color: "rgba(217,48,37,1)",
    fontSize: 40,
    left: 26
  }
});

export default CupertinoButtonWarning;
