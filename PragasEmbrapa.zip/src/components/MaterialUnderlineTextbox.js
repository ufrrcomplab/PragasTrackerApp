import React, { Component } from "react";
import { StyleSheet, View, TextInput } from "react-native";

function MaterialUnderlineTextbox(props) {
  return (
    <View style={[styles.container, props.style]}>
      <TextInput
        placeholder={props.inputStyle || "Placeholder"}
        style={styles.inputStyle}
      ></TextInput>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    borderBottomWidth: 1,
    borderColor: "#D9D5DC",
    backgroundColor: "transparent"
  },
  inputStyle: {
    color: "#000",
    fontFamily: "alegreya-sans-sc-regular",
    fontSize: 20,
    flex: 1,
    lineHeight: 16,
    textAlign: "left",
    height: 24,
    width: 360,
    marginTop: 9
  }
});

export default MaterialUnderlineTextbox;
