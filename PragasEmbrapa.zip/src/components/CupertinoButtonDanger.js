import React, { Component } from "react";
import { StyleSheet, TouchableOpacity, Text } from "react-native";

function CupertinoButtonDanger(props) {
  return (
    <TouchableOpacity style={[styles.container, props.style]}>
      <Text style={styles.button}>{props.button || "Button"}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "rgba(248,24,11,1)",
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    borderRadius: 10,
    paddingLeft: 16,
    paddingRight: 16,
    opacity: 0.8,
    borderWidth: 2,
    borderColor: "#000000"
  },
  button: {
    color: "rgba(0,0,0,1)",
    fontSize: 17,
    fontFamily: "aldrich-regular",
    opacity: 0.86
  }
});

export default CupertinoButtonDanger;
