import React, { Component } from "react";
import { StyleSheet, TouchableOpacity } from "react-native";

function ButtonCultura(props) {
  return (
    <TouchableOpacity
      style={[styles.container, props.style]}
    ></TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "rgba(185,235,197,1)",
    borderWidth: 4,
    borderColor: "rgba(243,241,241,1)",
    borderRadius: 12
  }
});

export default ButtonCultura;
