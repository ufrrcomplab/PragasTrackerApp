import React, { Component } from "react";
import { StyleSheet, View, Text } from "react-native";

function Data(props) {
  return (
    <View style={[styles.container, props.style]}>
      <Text style={styles.text}>25 /05/2019</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    opacity: 0.7,
    justifyContent: "center"
  },
  text: {
    fontFamily: "abeezee-regular",
    color: "rgba(0,0,0,1)",
    fontSize: 12,
    width: 90,
    height: 18,
    textAlign: "center",
    lineHeight: 20,
    alignSelf: "center"
  }
});

export default Data;
