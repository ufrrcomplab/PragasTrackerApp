import React, { Component } from "react";
import { StyleSheet, View, Text, TouchableOpacity } from "react-native";

function CupertinoSegmentWithTwoTabs(props) {
  return (
    <View style={[styles.container, props.style]}>
      <View style={styles.textWrapper}>
        <Text style={styles.titleLeft}>Puppies</Text>
        <TouchableOpacity style={styles.segmentTextWrapperRight}>
          <Text style={styles.titleRight}>Cubs</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "#FFF",
    justifyContent: "center"
  },
  textWrapper: {
    height: 56,
    flex: 1,
    flexDirection: "row",
    backgroundColor: "rgba(243,241,241,1)",
    width: 375
  },
  titleLeft: {
    fontSize: 13,
    color: "rgba(243,241,241,1)",
    position: "absolute",
    top: 8,
    left: 86,
    height: 15,
    width: 47
  },
  segmentTextWrapperRight: {
    flex: 1,
    alignItems: "center",
    backgroundColor: "#FFFFFF",
    padding: 6,
    borderWidth: 1,
    borderColor: "#007AFF",
    borderBottomRightRadius: 5,
    borderTopRightRadius: 5
  },
  titleRight: {
    fontSize: 13,
    color: "#007AFF"
  }
});

export default CupertinoSegmentWithTwoTabs;
