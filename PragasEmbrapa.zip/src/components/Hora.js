import React, { Component } from "react";
import { StyleSheet, View, Text } from "react-native";

function Hora(props) {
  return (
    <View style={[styles.container, props.style]}>
      <Text style={styles.loremIpsum}>23: 57</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "rgba(230, 230, 230,0)",
    justifyContent: "center"
  },
  loremIpsum: {
    fontFamily: "abeezee-regular",
    color: "rgba(126,211,33,1)",
    fontSize: 12,
    alignSelf: "center"
  }
});

export default Hora;
