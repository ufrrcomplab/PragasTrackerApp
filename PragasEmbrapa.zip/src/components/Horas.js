import React, { Component } from "react";
import { StyleSheet, View, Text } from "react-native";

function Horas(props) {
  return (
    <View style={[styles.container, props.style]}>
      <Text style={styles.text}>23 : 53</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "#E6E6E6",
    flexDirection: "row",
    alignItems: "baseline",
    justifyContent: "space-around"
  },
  text: {
    fontFamily: "abeezee-regular",
    color: "rgba(61,146,97,1)",
    width: 40,
    height: 10,
    fontSize: 12,
    margin: 0
  }
});

export default Horas;
