import React, { useState } from "react";
import { createAppContainer } from "react-navigation";
import { createStackNavigator } from "react-navigation-stack";
import { createDrawerNavigator } from "react-navigation-drawer";
import { AppLoading } from "expo";
import * as Font from "expo-font";
import TelaCapturaFoto1 from "./src/screens/TelaCapturaFoto1";
import TelaCapturaFoto2 from "./src/screens/TelaCapturaFoto2";
import TelaCapturaFoto3 from "./src/screens/TelaCapturaFoto3";
import TelaConfigPerfils from "./src/screens/TelaConfigPerfils";
import TelaDeEspera from "./src/screens/TelaDeEspera";
import TelaDeResultado1 from "./src/screens/TelaDeResultado1";
import TelaDeResultado2 from "./src/screens/TelaDeResultado2";
import TelaDeResultado3 from "./src/screens/TelaDeResultado3";
import TelaInit from "./src/screens/TelaInit";
import TelaLogin from "./src/screens/TelaLogin";
import TelaMenuInsetosPragas from "./src/screens/TelaMenuInsetosPragas";

const DrawerNavigation = createDrawerNavigator({
  TelaCapturaFoto1: TelaCapturaFoto1,
  TelaCapturaFoto2: TelaCapturaFoto2,
  TelaCapturaFoto3: TelaCapturaFoto3,
  TelaConfigPerfils: TelaConfigPerfils,
  TelaDeEspera: TelaDeEspera,
  TelaDeResultado1: TelaDeResultado1,
  TelaDeResultado2: TelaDeResultado2,
  TelaDeResultado3: TelaDeResultado3,
  TelaInit: TelaInit,
  TelaLogin: TelaLogin,
  TelaMenuInsetosPragas: TelaMenuInsetosPragas
});

const StackNavigation = createStackNavigator(
  {
    DrawerNavigation: {
      screen: DrawerNavigation
    },
    TelaCapturaFoto1: TelaCapturaFoto1,
    TelaCapturaFoto2: TelaCapturaFoto2,
    TelaCapturaFoto3: TelaCapturaFoto3,
    TelaConfigPerfils: TelaConfigPerfils,
    TelaDeEspera: TelaDeEspera,
    TelaDeResultado1: TelaDeResultado1,
    TelaDeResultado2: TelaDeResultado2,
    TelaDeResultado3: TelaDeResultado3,
    TelaInit: TelaInit,
    TelaLogin: TelaLogin,
    TelaMenuInsetosPragas: TelaMenuInsetosPragas
  },
  {
    headerMode: "none"
  }
);

const AppContainer = createAppContainer(StackNavigation);

function App() {
  const [isLoadingComplete, setLoadingComplete] = useState(false);
  if (!isLoadingComplete) {
    return (
      <AppLoading
        startAsync={loadResourcesAsync}
        onError={handleLoadingError}
        onFinish={() => handleFinishLoading(setLoadingComplete)}
      />
    );
  } else {
    return isLoadingComplete ? <AppContainer /> : <AppLoading />;
  }
}
async function loadResourcesAsync() {
  await Promise.all([
    Font.loadAsync({
      "abeezee-regular": require("./src/assets/fonts/abeezee-regular.ttf"),
      "aldrich-regular": require("./src/assets/fonts/aldrich-regular.ttf"),
      "roboto-regular": require("./src/assets/fonts/roboto-regular.ttf"),
      "alegreya-sans-sc-500": require("./src/assets/fonts/alegreya-sans-sc-500.ttf"),
      "alegreya-sans-sc-regular": require("./src/assets/fonts/alegreya-sans-sc-regular.ttf"),
      "alegreya-sans-sc-800": require("./src/assets/fonts/alegreya-sans-sc-800.ttf"),
      "alegreya-sans-sc-700": require("./src/assets/fonts/alegreya-sans-sc-700.ttf"),
      "alegreya-sc-700": require("./src/assets/fonts/alegreya-sc-700.ttf"),
      "alegreya-sc-500": require("./src/assets/fonts/alegreya-sc-500.ttf"),
      "alegreya-sc-regular": require("./src/assets/fonts/alegreya-sc-regular.ttf")
    })
  ]);
}
function handleLoadingError(error) {
  console.warn(error);
}

function handleFinishLoading(setLoadingComplete) {
  setLoadingComplete(true);
}

export default App;
