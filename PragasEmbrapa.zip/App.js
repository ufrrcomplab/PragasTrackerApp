import React, { useState } from "react";
import { createAppContainer } from "react-navigation";
import { createStackNavigator } from "react-navigation-stack";
import { createDrawerNavigator } from "react-navigation-drawer";
import AppLoading from "expo-app-loading";

import * as Font from "expo-font";
import TelaCapturaFoto1 from "./src/screens/TelaCapturaFoto1";
import TelaCapturaFoto2 from "./src/screens/TelaCapturaFoto2";
import TelaCapturaFoto4 from "./src/screens/TelaCapturaFoto4";
import TelaConfigPerfils from "./src/screens/TelaConfigPerfils";
import TelaDeEspera from "./src/screens/TelaDeEspera";
import TelaDeNovaTentaRes1 from "./src/screens/TelaDeNovaTentaRes1";
import TelaDeOutrasPragas from "./src/screens/TelaDeOutrasPragas";
import TelaDeParaPragas1 from "./src/screens/TelaDeParaPragas1";
import TelaDeRecomendacao from "./src/screens/TelaDeRecomendacao";
import TelaDeRecOutPragas from "./src/screens/TelaDeRecOutPragas";
import TelaDeResultado1 from "./src/screens/TelaDeResultado1";
import TelaDeResultado2 from "./src/screens/TelaDeResultado2";
import TelaDeTentaResultado from "./src/screens/TelaDeTentaResultado";
import TelaInit from "./src/screens/TelaInit";
import TelaLogin from "./src/screens/TelaLogin";
import TelaMenu from "./src/screens/TelaMenu";
import TelaMenuInsetosPragas from "./src/screens/TelaMenuInsetosPragas";

const DrawerNavigation = createDrawerNavigator({
  TelaCapturaFoto1: TelaCapturaFoto1,
  TelaCapturaFoto2: TelaCapturaFoto2,
  TelaCapturaFoto4: TelaCapturaFoto4,
  TelaConfigPerfils: TelaConfigPerfils,
  TelaDeEspera: TelaDeEspera,
  TelaDeNovaTentaRes1: TelaDeNovaTentaRes1,
  TelaDeOutrasPragas: TelaDeOutrasPragas,
  TelaDeParaPragas1: TelaDeParaPragas1,
  TelaDeRecomendacao: TelaDeRecomendacao,
  TelaDeRecOutPragas: TelaDeRecOutPragas,
  TelaDeResultado1: TelaDeResultado1,
  TelaDeResultado2: TelaDeResultado2,
  TelaDeTentaResultado: TelaDeTentaResultado,
  TelaInit: TelaInit,
  TelaLogin: TelaLogin,
  TelaMenu: TelaMenu,
  TelaMenuInsetosPragas: TelaMenuInsetosPragas
});

const StackNavigation = createStackNavigator(
  {
    DrawerNavigation: {
      screen: DrawerNavigation
    },
    TelaCapturaFoto1: TelaCapturaFoto1,
    TelaCapturaFoto2: TelaCapturaFoto2,
    TelaCapturaFoto4: TelaCapturaFoto4,
    TelaConfigPerfils: TelaConfigPerfils,
    TelaDeEspera: TelaDeEspera,
    TelaDeNovaTentaRes1: TelaDeNovaTentaRes1,
    TelaDeOutrasPragas: TelaDeOutrasPragas,
    TelaDeParaPragas1: TelaDeParaPragas1,
    TelaDeRecomendacao: TelaDeRecomendacao,
    TelaDeRecOutPragas: TelaDeRecOutPragas,
    TelaDeResultado1: TelaDeResultado1,
    TelaDeResultado2: TelaDeResultado2,
    TelaDeTentaResultado: TelaDeTentaResultado,
    TelaInit: TelaInit,
    TelaLogin: TelaLogin,
    TelaMenu: TelaMenu,
    TelaMenuInsetosPragas: TelaMenuInsetosPragas
  },
  {
    headerMode: "none"
  }
);

const AppContainer = createAppContainer(StackNavigation);

function App() {
  const [isLoadingComplete, setLoadingComplete] = useState(false);
  if (!isLoadingComplete) {
    return (
      <AppLoading
        startAsync={loadResourcesAsync}
        onError={handleLoadingError}
        onFinish={() => handleFinishLoading(setLoadingComplete)}
      />
    );
  } else {
    return isLoadingComplete ? <AppContainer /> : <AppLoading />;
  }
}
async function loadResourcesAsync() {
  await Promise.all([
    Font.loadAsync({
      "abeezee-regular": require("./src/assets/fonts/abeezee-regular.ttf"),
      "aldrich-regular": require("./src/assets/fonts/aldrich-regular.ttf"),
      "roboto-regular": require("./src/assets/fonts/roboto-regular.ttf"),
      "alegreya-sans-sc-regular": require("./src/assets/fonts/alegreya-sans-sc-regular.ttf"),
      "alegreya-sans-sc-500": require("./src/assets/fonts/alegreya-sans-sc-500.ttf"),
      "alegreya-sans-sc-700": require("./src/assets/fonts/alegreya-sans-sc-700.ttf"),
      "alegreya-sans-sc-800": require("./src/assets/fonts/alegreya-sans-sc-800.ttf"),
      "alegreya-sc-regular": require("./src/assets/fonts/alegreya-sc-regular.ttf"),
      "alegreya-sc-700": require("./src/assets/fonts/alegreya-sc-700.ttf"),
      "alegreya-sc-500": require("./src/assets/fonts/alegreya-sc-500.ttf")
    })
  ]);
}
function handleLoadingError(error) {
  console.warn(error);
}

function handleFinishLoading(setLoadingComplete) {
  setLoadingComplete(true);
}

export default App;
